// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDDJDiANpdG8L5a0JZhMW5u08LB5d8Cfug",
  authDomain: "gestionale-55273.firebaseapp.com",
  projectId: "gestionale-55273",
  storageBucket: "gestionale-55273.firebasestorage.app",
  messagingSenderId: "230648983559",
  appId: "1:230648983559:web:47df609fa20e37c340faa2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

