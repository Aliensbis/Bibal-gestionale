import { DailyProduction } from '@/types/production'

export async function saveProduction(production: DailyProduction): Promise<void> {
  const existingData = localStorage.getItem('productionData')
  const productionData: DailyProduction[] = existingData ? JSON.parse(existingData) : []
  
  // Check if we already have data for this date
  const existingIndex = productionData.findIndex(p => p.date === production.date)
  
  if (existingIndex !== -1) {
    // Update existing production data
    productionData[existingIndex] = production
  } else {
    // Add new production data
    productionData.push(production)
  }
  
  localStorage.setItem('productionData', JSON.stringify(productionData))
  await new Promise(resolve => setTimeout(resolve, 500)) // Simulate API delay
}

export async function getAllProductions(): Promise<DailyProduction[]> {
  const data = localStorage.getItem('productionData')
  await new Promise(resolve => setTimeout(resolve, 500)) // Simulate API delay
  return data ? JSON.parse(data) : []
}

export async function getProductionsByDateRange(startDate: string, endDate: string): Promise<DailyProduction[]> {
  const allProductions = await getAllProductions()
  return allProductions.filter(prod => prod.date >= startDate && prod.date <= endDate)
}

