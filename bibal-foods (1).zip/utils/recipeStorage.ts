import { Product } from '@/types/production'
import { products as defaultProducts } from '@/utils/productionData'
import { toast } from 'react-hot-toast'

const RECIPES_STORAGE_KEY = 'recipes_data'

export async function initializeRecipes() {
  const storedProducts = localStorage.getItem(RECIPES_STORAGE_KEY)
  if (!storedProducts) {
    // Initialize with default products from productionData
    localStorage.setItem(RECIPES_STORAGE_KEY, JSON.stringify(defaultProducts))
    return defaultProducts
  }
  return JSON.parse(storedProducts)
}

export async function updateRecipe(recipeId: string, updates: Partial<Product>) {
  try {
    // Get current products
    const storedProducts = localStorage.getItem(RECIPES_STORAGE_KEY)
    let products: Product[] = storedProducts ? JSON.parse(storedProducts) : defaultProducts
    
    // Update the specific recipe
    products = products.map(product => 
      product.id === recipeId ? { ...product, ...updates } : product
    )
    
    // Save back to storage
    localStorage.setItem(RECIPES_STORAGE_KEY, JSON.stringify(products))
    
    // Also update the production data to keep in sync
    const productionData = localStorage.getItem('productionData')
    if (productionData) {
      const parsedData = JSON.parse(productionData)
      // Update recipe in production data
      if (parsedData.products) {
        parsedData.products = parsedData.products.map((product: Product) =>
          product.id === recipeId ? { ...product, ...updates } : product
        )
        localStorage.setItem('productionData', JSON.stringify(parsedData))
      }
    }
    
    return products
  } catch (error) {
    console.error('Error updating recipe:', error)
    throw new Error('Failed to update recipe')
  }
}

export async function addRecipe(newRecipe: Omit<Product, 'id'>): Promise<Product[]> {
  try {
    const storedProducts = localStorage.getItem(RECIPES_STORAGE_KEY)
    let products: Product[] = storedProducts ? JSON.parse(storedProducts) : defaultProducts

    const newId = Date.now().toString()
    const recipeWithId: Product = { ...newRecipe, id: newId }

    products.push(recipeWithId)
    localStorage.setItem(RECIPES_STORAGE_KEY, JSON.stringify(products))

    // Also update the production data
    const productionData = localStorage.getItem('productionData')
    if (productionData) {
      const parsedData = JSON.parse(productionData)
      if (parsedData.products) {
        parsedData.products.push(recipeWithId)
        localStorage.setItem('productionData', JSON.stringify(parsedData))
      }
    }

    return products
  } catch (error) {
    console.error('Error adding new recipe:', error)
    throw new Error('Failed to add new recipe')
  }
}

export async function getAllRecipes(): Promise<Product[]> {
  const recipes = await initializeRecipes()
  return recipes
}

