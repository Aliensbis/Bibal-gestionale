import { ClientStats, OrderHistoryItem } from '@/types/statistics'

// Mock data generator
export function generateMockData(): { clients: ClientStats[], orders: OrderHistoryItem[] } {
  const clients: ClientStats[] = [
    {
      id: '1',
      name: 'Cliente A',
      orders: 120,
      boxes: 1200,
      classification: 'Premium',
      stats: {
        weekly: { count: 3, total: 30, trend: 5.2 },
        monthly: { count: 12, total: 120, trend: 3.8 },
        yearly: { count: 120, total: 1200, trend: 15.5 }
      }
    },
    {
      id: '2',
      name: 'Cliente B',
      orders: 85,
      boxes: 850,
      classification: 'Gold',
      stats: {
        weekly: { count: 2, total: 20, trend: 2.1 },
        monthly: { count: 8, total: 80, trend: 1.5 },
        yearly: { count: 85, total: 850, trend: 10.2 }
      }
    }
  ]

  const orders: OrderHistoryItem[] = [
    {
      id: '1',
      date: '2025-01-07',
      boxes: 18,
      products: [
        { id: '1', name: 'Babà Mignon', boxes: 6, cartonsPerBatch: 5, batches: 2 },
        { id: '2', name: 'Babà Grande', boxes: 12, cartonsPerBatch: 4, batches: 3 }
      ],
      status: 'in-progress'
    },
    {
      id: '2',
      date: '2025-01-06',
      boxes: 15,
      products: [
        { id: '3', name: 'Savarè Mignon', boxes: 8, cartonsPerBatch: 4, batches: 2 },
        { id: '4', name: 'Bignè 45', boxes: 7, cartonsPerBatch: 6, batches: 2 }
      ],
      status: 'completed'
    }
  ]

  return { clients, orders }
}

// Local storage management
const STORAGE_KEY = 'statistics_data'

export function saveData(data: { clients: ClientStats[], orders: OrderHistoryItem[] }) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
}

export function loadData(): { clients: ClientStats[], orders: OrderHistoryItem[] } {
  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored) {
    return JSON.parse(stored)
  }
  const initialData = generateMockData()
  saveData(initialData)
  return initialData
}

export function updateClient(clientId: string, updates: Partial<ClientStats>) {
  const data = loadData()
  const clientIndex = data.clients.findIndex(c => c.id === clientId)
  if (clientIndex !== -1) {
    data.clients[clientIndex] = { ...data.clients[clientIndex], ...updates }
    saveData(data)
  }
  return data.clients
}

export function updateOrder(orderId: string, updates: Partial<OrderHistoryItem>) {
  const data = loadData()
  const orderIndex = data.orders.findIndex(o => o.id === orderId)
  if (orderIndex !== -1) {
    data.orders[orderIndex] = { ...data.orders[orderIndex], ...updates }
    saveData(data)
  }
  return data.orders
}

