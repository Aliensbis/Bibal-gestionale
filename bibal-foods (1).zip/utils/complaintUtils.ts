import { ComplaintSeverity, ComplaintStatus } from '@/types/complaints'

export const getSeverityColor = (severity: ComplaintSeverity) => {
  switch (severity) {
    case 'critical': return 'text-red-600 bg-red-50'
    case 'high': return 'text-orange-600 bg-orange-50'
    case 'medium': return 'text-yellow-600 bg-yellow-50'
    case 'low': return 'text-green-600 bg-green-50'
  }
}

export const getStatusColor = (status: ComplaintStatus) => {
  switch (status) {
    case 'pending': return 'text-yellow-600 bg-yellow-50'
    case 'in-progress': return 'text-blue-600 bg-blue-50'
    case 'resolved': return 'text-green-600 bg-green-50'
  }
}

