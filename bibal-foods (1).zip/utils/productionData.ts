import { Product } from '@/types/production'

export const products: Product[] = [
  {
    id: 'baba-mignon',
    name: 'Babà Mignon',
    cartonsPerBatch: 5,
    category: 'Babà',
    ingredients: {
      flour: { amount: 13, type: 'S' },
      eggs: 7.5,
      sugar: 0.4,
      salt: 0.3,
      yeast: 0.11,
      margarine: 2.9,
      e202: 0.002
    }
  },
  {
    id: 'baba-mignon-morbido',
    name: 'Babà Mignon Morbido',
    cartonsPerBatch: 8,
    category: 'Babà',
    ingredients: {
      flour: { amount: 13, type: 'S' },
      eggs: 7.5,
      sugar: 0.4,
      salt: 0.3,
      yeast: 0.11,
      margarine: 2.9,
      e202: 0.002
    }
  },
  {
    id: 'baba-grande',
    name: 'Babà Grande',
    cartonsPerBatch: 4,
    category: 'Babà',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.6,
      salt: 0.2,
      yeast: 0.11,
      margarine: 3,
      e202: 0.001
    }
  },
  {
    id: 'baba-grande-morbido',
    name: 'Babà Grande Morbido',
    cartonsPerBatch: 5,
    category: 'Babà',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.6,
      salt: 0.2,
      yeast: 0.11,
      margarine: 3,
      e202: 0.001
    }
  },
  {
    id: 'baba-medio',
    name: 'Babà Medio',
    cartonsPerBatch: 6,
    category: 'Babà',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.6,
      salt: 0.23,
      yeast: 0.11,
      margarine: 3
    }
  },
  {
    id: 'baba-120-pz',
    name: 'Babà 120 pz.',
    cartonsPerBatch: 4,
    category: 'Babà',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.5,
      salt: 0.3,
      yeast: 0.11,
      margarine: 3,
      e202: 0.001
    }
  },
  {
    id: 'baba-60-pz',
    name: 'Babà 60 pz.',
    cartonsPerBatch: 4,
    category: 'Babà',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.5,
      salt: 0.3,
      yeast: 0.11,
      margarine: 3,
      e202: 0.001
    }
  },
  {
    id: 'baba-micro',
    name: 'Babà Micro',
    cartonsPerBatch: 3,
    category: 'Babà',
    ingredients: {
      flour: { amount: 8, type: '0' },
      eggs: 8,
      sugar: 0.5,
      salt: 0.2,
      yeast: 0.105,
      margarine: 1.8,
      e202: 0.0001
    }
  },
  {
    id: 'baba-micro-morbido',
    name: 'Babà Micro Morbido',
    cartonsPerBatch: 8,
    category: 'Babà',
    ingredients: {
      flour: { amount: 8, type: '0' },
      eggs: 8,
      sugar: 0.5,
      salt: 0.2,
      yeast: 0.105,
      margarine: 1.8,
      e202: 0.0001
    }
  },
  {
    id: 'savare-micro',
    name: 'Savarè Micro',
    cartonsPerBatch: 3,
    category: 'Savarè',
    ingredients: {
      flour: { amount: 8, type: '0' },
      eggs: 8,
      sugar: 0.5,
      salt: 0.2,
      yeast: 0.105,
      margarine: 1.8,
      e202: 0.0001
    }
  },
  {
    id: 'savare-mignon',
    name: 'Savarè Mignon',
    cartonsPerBatch: 4,
    category: 'Savarè',
    ingredients: {
      flour: { amount: 10.7, type: 'S' },
      eggs: 8,
      sugar: 0.5,
      salt: 0.25,
      yeast: 0.11,
      margarine: 1.9,
      e202: 0.0005
    }
  },
  {
    id: 'savare-mignon-morbido',
    name: 'Savarè Mignon Morbido',
    cartonsPerBatch: 6,
    category: 'Savarè',
    ingredients: {
      flour: { amount: 10.7, type: 'S' },
      eggs: 8,
      sugar: 0.5,
      salt: 0.25,
      yeast: 0.11,
      margarine: 1.9,
      e202: 0.0005
    }
  },
  {
    id: 'savare-grande',
    name: 'Savarè Grande',
    cartonsPerBatch: 4,
    category: 'Savarè',
    ingredients: {
      flour: { amount: 10, type: 'M' },
      eggs: 10,
      sugar: 0.5,
      salt: 0.3,
      yeast: 0.11,
      margarine: 3,
      e202: 0.001
    }
  },
  {
    id: 'bigne-45',
    name: 'Bignè 45',
    cartonsPerBatch: 6,
    category: 'Bignè',
    ingredients: {
      flour: { amount: 5.1, type: 'Bignè' },
      eggs: 8,
      sugar: 0.045,
      salt: 0,
      yeast: 0.065,
      margarine: 3.2,
      oil: 3.2
    }
  },
  {
    id: 'bigne-85',
    name: 'Bignè 85',
    cartonsPerBatch: 4,
    category: 'Bignè',
    ingredients: {
      flour: { amount: 5.1, type: 'Bignè' },
      eggs: 8,
      sugar: 0.045,
      salt: 0,
      yeast: 0.08,
      margarine: 3.2,
      oil: 3.2
    }
  },
  {
    id: 'bigne-25',
    name: 'Bignè 25',
    cartonsPerBatch: 5,
    category: 'Bignè',
    ingredients: {
      flour: { amount: 5.1, type: 'Bignè' },
      eggs: 8,
      sugar: 0.045,
      salt: 0,
      yeast: 0.045,
      margarine: 3.2,
      oil: 3.2
    }
  }
]

