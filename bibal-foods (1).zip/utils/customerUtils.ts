import { Customer, Order, CustomerAnalytics } from '@/types/customer'

export async function getCustomers(): Promise<Customer[]> {
  // In a real application, this would be an API call
  return [
    { id: '1', name: 'Cliente A' },
    { id: '2', name: 'Cliente B' },
    { id: '3', name: 'Cliente C' },
  ]
}

export async function getCustomerOrders(customerId: string): Promise<Order[]> {
  // In a real application, this would be an API call
  return [
    { id: '1', date: '2023-05-01', total: 500, status: 'completed' },
    { id: '2', date: '2023-05-15', total: 750, status: 'in-progress' },
    { id: '3', date: '2023-05-30', total: 1000, status: 'pending' },
  ]
}

export function calculateCustomerMetrics(orders: Order[]) {
  const totalOrders = orders.length
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)
  const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0
  const totalBoxes = orders.reduce((sum, order) => sum + (order.boxes || 0), 0)

  return {
    totalOrders,
    totalRevenue,
    averageOrderValue,
    totalBoxes,
  }
}

export function calculateTrends(metrics: ReturnType<typeof calculateCustomerMetrics>, period: 'week' | 'month' | 'year'): CustomerAnalytics {
  // This is a simplified trend calculation. In a real application, you'd compare current period to previous period.
  const trend = Math.random() * 20 - 10 // Random trend between -10% and 10%

  return {
    weekly: {
      orders: metrics.totalOrders,
      boxes: metrics.totalBoxes,
      trend,
    },
    monthly: {
      orders: metrics.totalOrders * 4,
      boxes: metrics.totalBoxes * 4,
      trend,
    },
    yearly: {
      orders: metrics.totalOrders * 52,
      boxes: metrics.totalBoxes * 52,
      trend,
    },
    rank: getCustomerTier(metrics.totalOrders),
  }
}

export function getCustomerTier(totalOrders: number) {
  if (totalOrders >= 100) return { tier: 'Premium', color: 'text-purple-600', percentile: 95 };
  if (totalOrders >= 50) return { tier: 'Gold', color: 'text-yellow-600', percentile: 80 };
  if (totalOrders >= 20) return { tier: 'Silver', color: 'text-gray-600', percentile: 60 };
  return { tier: 'Bronze', color: 'text-orange-600', percentile: 40 };
}

