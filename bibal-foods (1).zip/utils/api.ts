import { cache } from 'react'

export const fetchWithCache = cache(async (url: string) => {
  const res = await fetch(url, { next: { revalidate: 60 } })
  
  if (!res.ok) {
    throw new Error(`HTTP error! status: ${res.status}`)
  }
  
  const contentType = res.headers.get("content-type")
  if (contentType && contentType.indexOf("application/json") !== -1) {
    return res.json()
  } else {
    throw new Error("Oops, we haven't got JSON!")
  }
})

export async function fetchProductionData() {
  try {
    return await fetchWithCache('/api/production')
  } catch (error) {
    console.error('Error fetching production data:', error)
    return { entries: [] }
  }
}

export async function fetchOrderData() {
  try {
    return await fetchWithCache('/api/orders')
  } catch (error) {
    console.error('Error fetching order data:', error)
    return { orders: [] }
  }
}

