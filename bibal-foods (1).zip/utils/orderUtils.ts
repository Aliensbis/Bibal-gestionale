import { ref, onValue, push, update } from 'firebase/database'
import { db } from '@/lib/firebase'
import { Order, OrderStatus } from '@/types/orders'

export const subscribeToOrders = (callback: (orders: Order[]) => void) => {
  const ordersRef = ref(db, 'orders')
  const unsubscribe = onValue(ordersRef, (snapshot) => {
    const orders: Order[] = []
    snapshot.forEach((childSnapshot) => {
      orders.push({ id: childSnapshot.key, ...childSnapshot.val() })
    })
    callback(orders)
  })
  return unsubscribe
}

export const createOrder = async (orderData: Omit<Order, 'id'>) => {
  const ordersRef = ref(db, 'orders')
  const newOrderRef = push(ordersRef)
  await update(newOrderRef, orderData)

  // Notify Production - Commented out as per update request
  // addNotification({
  //   userId: 'production',
  //   title: 'Nuovo Ordine',
  //   message: `Nuovo ordine da ${orderData.customerName}`
  // })

  return { id: newOrderRef.key, ...orderData }
}

export const updateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
  const orderRef = ref(db, `orders/${orderId}`)
  await update(orderRef, { status: newStatus })

  // Notify stakeholders based on the new status - Commented out as per update request
  // if (newStatus === 'completed') {
  //   addNotification({
  //     userId: 'admin',
  //     title: 'Ordine Completato',
  //     message: `Ordine #${orderId} completato dalla produzione`
  //   })
  // }

  // if (newStatus === 'ready-for-pickup') {
  //   addNotification({
  //     userId: 'agent',
  //     title: 'Ordine Pronto per il Ritiro',
  //     message: `Ordine #${orderId} è pronto per il ritiro`
  //   })
  // }
}

export const generateDeliveryNote = async (orderId: string) => {
  // Implement PDF generation logic here
  // You can use a library like jsPDF or pdfmake
  console.log(`Generating delivery note for order ${orderId}`)
}

