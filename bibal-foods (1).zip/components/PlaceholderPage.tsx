interface PlaceholderPageProps {
  accountType: 'produzione' | 'amministrazione' | 'agenti'
  title: string
}

export function PlaceholderPage({ accountType, title }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">{title}</h1>
        <p className="text-gray-600">
          Questa pagina è in fase di sviluppo. Torneremo presto con nuove funzionalità!
        </p>
      </main>
    </div>
  )
}

