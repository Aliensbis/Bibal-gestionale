'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Edit2, Save, X, ChevronDown, ChevronUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OrderHistoryItem } from '@/types/statistics'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface OrderHistoryProps {
  orders: OrderHistoryItem[]
  onUpdateOrder: (orderId: string, updates: Partial<OrderHistoryItem>) => void
}

export function OrderHistory({ orders, onUpdateOrder }: OrderHistoryProps) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editBoxes, setEditBoxes] = useState<number>(0)
  const [expandedOrders, setExpandedOrders] = useState<string[]>([])

  const handleEdit = (order: OrderHistoryItem) => {
    setEditingId(order.id)
    setEditBoxes(order.boxes)
  }

  const handleSave = (orderId: string) => {
    onUpdateOrder(orderId, { boxes: editBoxes })
    setEditingId(null)
  }

  const handleCancel = () => {
    setEditingId(null)
  }

  const toggleOrderExpansion = (orderId: string) => {
    setExpandedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Storico Ordini Mensile</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {orders.map((order) => (
            <motion.div
              key={order.id}
              className="border rounded-lg p-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-4">
                  <span className="font-medium">
                    {new Date(order.date).toLocaleDateString('it-IT', {
                      weekday: 'long',
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                  <span className="px-2 py-1 text-sm rounded-full bg-yellow-100 text-yellow-800">
                    {order.status === 'pending' ? 'In Attesa' : 
                     order.status === 'in-progress' ? 'In Lavorazione' : 'Completato'}
                  </span>
                </div>
                {editingId === order.id ? (
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={editBoxes}
                      onChange={(e) => setEditBoxes(Number(e.target.value))}
                      className="w-24"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleSave(order.id)}
                    >
                      <Save className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleCancel}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span>{order.boxes} cartoni totali</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleEdit(order)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => toggleOrderExpansion(order.id)}
                    >
                      {expandedOrders.includes(order.id) ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                )}
              </div>
              {expandedOrders.includes(order.id) && (
                <div className="mt-4 space-y-2">
                  {order.products.map((product) => (
                    <div key={product.id} className="bg-gray-50 p-2 rounded-md">
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-gray-600">
                        {product.boxes} cartoni | {product.batches} pesate | {product.cartonsPerBatch} cartoni per pesata
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
          {orders.length === 0 && (
            <p className="text-center text-gray-500 py-8">
              Nessun ordine registrato
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

