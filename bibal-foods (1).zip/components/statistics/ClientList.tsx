'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Edit2, Save, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ClientStats } from '@/types/statistics'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface ClientListProps {
  clients: ClientStats[]
  selectedClientId: string | null
  onSelectClient: (clientId: string) => void
  onUpdateClient: (clientId: string, updates: Partial<ClientStats>) => void
}

export function ClientList({
  clients,
  selectedClientId,
  onSelectClient,
  onUpdateClient
}: ClientListProps) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')

  const handleEdit = (client: ClientStats) => {
    setEditingId(client.id)
    setEditName(client.name)
  }

  const handleSave = (clientId: string) => {
    onUpdateClient(clientId, { name: editName })
    setEditingId(null)
  }

  const handleCancel = () => {
    setEditingId(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Clienti</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {clients.map((client) => (
            <motion.div
              key={client.id}
              className={`p-4 rounded-lg cursor-pointer ${
                client.id === selectedClientId ? 'bg-blue-50' : 'hover:bg-gray-50'
              }`}
              onClick={() => onSelectClient(client.id)}
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center justify-between mb-2">
                {editingId === client.id ? (
                  <div className="flex items-center gap-2 w-full">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="flex-1"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleSave(client.id)}
                    >
                      <Save className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleCancel}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <span className="font-medium">{client.name}</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleEdit(client)
                      }}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
              <div className="text-sm text-gray-500">
                {client.orders} ordini • {client.boxes} cartoni
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

