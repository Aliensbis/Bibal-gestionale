'use client'

import { motion } from 'framer-motion'
import { Package, TrendingUp, Award } from 'lucide-react'
import { ClientStats } from '@/types/statistics'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface StatsDisplayProps {
  client: ClientStats
  period: 'weekly' | 'monthly' | 'yearly'
}

export function StatsDisplay({ client, period }: StatsDisplayProps) {
  const stats = client.stats[period]
  
  const getPeriodLabel = () => {
    switch(period) {
      case 'weekly':
        return 'Settimanali'
      case 'monthly':
        return 'Mensili'
      case 'yearly':
        return 'Annuali'
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <CardTitle className="text-lg font-medium text-gray-700">
              Ordini {getPeriodLabel()}
            </CardTitle>
            <Package className="w-8 h-8 text-blue-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">{stats.count}</span>
            {stats.trend !== 0 && (
              <span className={`text-sm ${stats.trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {stats.trend > 0 ? '+' : ''}{stats.trend}%
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <CardTitle className="text-lg font-medium text-gray-700">
              Cartoni {getPeriodLabel()}
            </CardTitle>
            <TrendingUp className="w-8 h-8 text-green-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">{stats.total}</span>
            {stats.trend !== 0 && (
              <span className={`text-sm ${stats.trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {stats.trend > 0 ? '+' : ''}{stats.trend}%
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <CardTitle className="text-lg font-medium text-gray-700">
              Classificazione Cliente
            </CardTitle>
            <Award className="w-8 h-8 text-purple-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-purple-600">{client.classification}</span>
            <span className="text-sm text-gray-500">Top {stats.trend}%</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

