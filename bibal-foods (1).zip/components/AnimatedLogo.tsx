'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'

export function AnimatedLogo() {
  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      whileHover={{ scale: 1.05 }}
      className="relative w-32 h-12"
    >
      <Image
        src="/logo-bibal-foods.png"
        alt="Bibal Foods Logo"
        fill
        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        className="object-contain"
        priority
      />
    </motion.div>
  )
}

