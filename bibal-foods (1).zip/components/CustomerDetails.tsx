import { Order, CustomerAnalytics } from '@/types/customer'
import { formatCurrency } from '@/utils/formatters'

interface CustomerDetailsProps {
  customerId: string | null
  orders: Order[]
  stats: CustomerAnalytics
}

export function CustomerDetails({ customerId, orders, stats }: CustomerDetailsProps) {
  if (!customerId || !stats) return null

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-2xl font-semibold mb-4">Dettagli Cliente</h2>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <h3 className="text-lg font-medium mb-2">Rango Cliente</h3>
          <p className={`text-xl font-bold ${stats.rank?.color}`}>{stats.rank?.tier}</p>
          <p className="text-sm text-gray-500">Top {stats.rank?.percentile}%</p>
        </div>
        <div>
          <h3 className="text-lg font-medium mb-2">Performance Annuale</h3>
          <p className="text-xl font-bold">{stats.yearly?.orders} ordini</p>
          <p className="text-sm text-gray-500">{stats.yearly?.boxes} cartoni</p>
        </div>
      </div>
      <h3 className="text-lg font-medium mb-2">Ultimi Ordini</h3>
      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-600">
            <th className="pb-2">Data</th>
            <th className="pb-2">Totale</th>
            <th className="pb-2">Stato</th>
          </tr>
        </thead>
        <tbody>
          {orders.slice(0, 5).map((order) => (
            <tr key={order.id} className="border-t">
              <td className="py-2">{new Date(order.date).toLocaleDateString()}</td>
              <td className="py-2">{formatCurrency(order.total)}</td>
              <td className="py-2">{order.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

