'use client'

import { useState, useEffect } from 'react'
import { Complaint, ComplaintStatus } from '@/types/complaints'
import { ComplaintCard } from '@/components/complaint-card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'react-hot-toast'

// This would typically come from an API or database
const mockComplaints: Complaint[] = [
  {
    id: '1',
    customerId: 'CUST001',
    description: 'Prodotto danneggiato durante la spedizione',
    severity: 'high',
    status: 'pending',
    images: ['/placeholder.svg?height=200&width=200'],
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    customerId: 'CUST002',
    description: 'Ordine incompleto',
    severity: 'medium',
    status: 'in-progress',
    images: [],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  // Add more mock complaints as needed
]

export function ComplaintsList() {
  const [complaints, setComplaints] = useState<Complaint[]>(mockComplaints)
  const [filteredComplaints, setFilteredComplaints] = useState<Complaint[]>(mockComplaints)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | 'all'>('all')

  useEffect(() => {
    // This would be replaced with a real-time subscription in a production app
    const interval = setInterval(() => {
      // Check for new complaints and update state
      // For now, we'll just use the mock data
      setComplaints(mockComplaints)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    setFilteredComplaints(
      complaints.filter(complaint =>
        (statusFilter === 'all' || complaint.status === statusFilter) &&
        (complaint.customerId.toLowerCase().includes(searchTerm.toLowerCase()) ||
         complaint.description.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    )
  }, [complaints, searchTerm, statusFilter])

  const handleStatusChange = (id: string, status: ComplaintStatus) => {
    setComplaints(complaints.map(complaint =>
      complaint.id === id ? { ...complaint, status } : complaint
    ))

    // This would typically be an API call
    // updateComplaintStatus(id, status)

    toast.success(`Stato del reclamo #${id} aggiornato a ${status}`)

    if (status === 'in-progress') {
      // This would typically be an API call
      // notifyAdmin({
      //   type: 'complaint_update',
      //   message: `Reclamo #${id} preso in carico dalla produzione`
      // })
      toast.success(`Notifica inviata all'amministrazione per il reclamo #${id}`)
    }
  }

  const handleResolution = (id: string, resolution: string) => {
    setComplaints(complaints.map(complaint =>
      complaint.id === id ? { ...complaint, status: 'resolved', resolution } : complaint
    ))

    // This would typically be an API call
    // updateComplaintResolution(id, resolution)

    toast.success(`Reclamo #${id} risolto`)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <Input
          placeholder="Cerca per cliente o descrizione..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-grow"
        />
        <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as ComplaintStatus | 'all')}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filtra per stato" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti gli stati</SelectItem>
            <SelectItem value="pending">In Attesa</SelectItem>
            <SelectItem value="in-progress">In Lavorazione</SelectItem>
            <SelectItem value="resolved">Risolti</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-4">
        {filteredComplaints.map(complaint => (
          <ComplaintCard
            key={complaint.id}
            complaint={complaint}
            onStatusChange={handleStatusChange}
            onResolution={handleResolution}
          />
        ))}
        {filteredComplaints.length === 0 && (
          <p className="text-center text-gray-500">Nessun reclamo trovato</p>
        )}
      </div>
    </div>
  )
}

