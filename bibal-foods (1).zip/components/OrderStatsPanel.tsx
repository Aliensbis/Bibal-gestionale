interface OrderStatsPanelProps {
  stats: OrderStats
}

export function OrderStatsPanel({ stats }: OrderStatsPanelProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Totale Ordini</h3>
        <p className="text-2xl font-bold mt-1">{stats.total}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">In Attesa</h3>
        <p className="text-2xl font-bold mt-1 text-yellow-600">{stats.pending}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">In Produzione</h3>
        <p className="text-2xl font-bold mt-1 text-blue-600">{stats.inProgress}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Completati</h3>
        <p className="text-2xl font-bold mt-1 text-green-600">{stats.completed}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Totale Cartoni</h3>
        <p className="text-2xl font-bold mt-1">{stats.totalBoxes}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Totale Pallet</h3>
        <p className="text-2xl font-bold mt-1">{stats.totalPallets}</p>
      </div>
    </div>
  )
}

