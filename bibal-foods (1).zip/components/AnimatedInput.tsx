'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'

interface AnimatedInputProps {
  type: string
  label: string
  id: string
  required?: boolean
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export function AnimatedInput({ type, label, id, required = false, value, onChange }: AnimatedInputProps) {
  const [isFocused, setIsFocused] = useState(false)

  return (
    <motion.div 
      className="relative mb-4"
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <motion.label
        htmlFor={id}
        className="block text-sm font-medium text-gray-700 mb-1"
        animate={{
          y: isFocused || value ? -20 : 0,
          scale: isFocused || value ? 0.8 : 1,
          color: isFocused ? '#B8860B' : '#6B7280'
        }}
      >
        {label}
      </motion.label>
      <motion.input
        type={type}
        id={id}
        required={required}
        value={value}
        onChange={onChange}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#B8860B] focus:ring-offset-2 focus:border-[#B8860B]"
        animate={{
          scale: isFocused ? 1.01 : 1
        }}
      />
    </motion.div>
  )
}

