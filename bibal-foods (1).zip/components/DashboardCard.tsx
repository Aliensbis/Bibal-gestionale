'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { TypeIcon as type, LucideIcon } from 'lucide-react'

interface DashboardCardProps {
  icon: LucideIcon
  title: string
  description: string
  href: string
  iconColor: string
}

export function DashboardCard({ icon: Icon, title, description, href, iconColor }: DashboardCardProps) {
  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Link href={href}>
        <div className="bg-white rounded-lg shadow-md p-6 h-full hover:shadow-lg transition-shadow border border-gray-200">
          <div className="flex items-center mb-4">
            <div className={`p-3 rounded-full ${iconColor.replace('text-', 'bg-')} bg-opacity-10 mr-4`}>
              <Icon className={`w-6 h-6 ${iconColor}`} />
            </div>
            <h3 className="text-lg font-semibold">{title}</h3>
          </div>
          <p className="text-gray-600 text-sm">{description}</p>
        </div>
      </Link>
    </motion.div>
  )
}

