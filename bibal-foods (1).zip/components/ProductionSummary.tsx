'use client'

import { motion } from 'framer-motion'
import { ProductionEntry } from '@/types/production'

interface ProductionSummaryProps {
  entries: ProductionEntry[]
}

export function ProductionSummary({ entries }: ProductionSummaryProps) {
  const totals = entries.reduce((acc, entry) => ({
    cartons: acc.cartons + entry.cartons,
    batches: acc.batches + entry.batches,
    ingredients: {
      flour: acc.ingredients.flour + entry.ingredients.flour,
      eggs: acc.ingredients.eggs + entry.ingredients.eggs,
      sugar: acc.ingredients.sugar + entry.ingredients.sugar,
      salt: acc.ingredients.salt + entry.ingredients.salt,
      yeast: acc.ingredients.yeast + entry.ingredients.yeast,
      margarine: acc.ingredients.margarine + entry.ingredients.margarine,
      e202: acc.ingredients.e202 + (entry.ingredients.e202 || 0),
      oil: acc.ingredients.oil + (entry.ingredients.oil || 0)
    }
  }), {
    cartons: 0,
    batches: 0,
    ingredients: {
      flour: 0,
      eggs: 0,
      sugar: 0,
      salt: 0,
      yeast: 0,
      margarine: 0,
      e202: 0,
      oil: 0
    }
  })

  const flourBags = Math.ceil(totals.ingredients.flour / 25)
  const eggCartons = Math.ceil(totals.ingredients.eggs / 20)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-md"
    >
      <h2 className="text-xl font-semibold mb-4">Riepilogo Produzione</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-medium mb-2">Totali</h3>
          <p>Cartoni: {totals.cartons}</p>
          <p>Pesate: {totals.batches}</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-medium mb-2">Farina</h3>
          <p>Totale: {totals.ingredients.flour.toFixed(2)} kg</p>
          <p>Sacchi: {flourBags}</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-medium mb-2">Uova</h3>
          <p>Totale: {totals.ingredients.eggs.toFixed(2)} kg</p>
          <p>Cartoni: {eggCartons}</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-medium mb-2">Altri Ingredienti</h3>
          <p>Zucchero: {totals.ingredients.sugar.toFixed(2)} kg</p>
          <p>Margarina: {totals.ingredients.margarine.toFixed(2)} kg</p>
        </div>
      </div>
    </motion.div>
  )
}

