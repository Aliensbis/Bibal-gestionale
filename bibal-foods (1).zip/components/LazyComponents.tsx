import dynamic from 'next/dynamic'

export const LazyFloatingHelpButton = dynamic(
  () => import('./FloatingHelpButton').then(mod => mod.FloatingHelpButton),
  { ssr: false }
)

export const LazyProductionSummary = dynamic(
  () => import('./ProductionSummary').then(mod => mod.ProductionSummary),
  { loading: () => <p>Caricamento riepilogo...</p> }
)

export const LazyOrderList = dynamic(
  () => import('./OrderList').then(mod => mod.OrderList),
  { loading: () => <p>Caricamento ordini...</p> }
)

