'use client'

import { Toaster as HotToaster } from 'react-hot-toast'

export function Toaster() {
  return (
    <HotToaster
      position="bottom-right"
      toastOptions={{
        className: 'bg-white text-gray-900 border border-gray-200',
        duration: 5000,
      }}
    />
  )
}

