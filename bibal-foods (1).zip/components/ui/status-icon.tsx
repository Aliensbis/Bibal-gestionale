'use client'

import { motion } from 'framer-motion'
import { Clock, CheckCircle, Package, Truck, Box } from 'lucide-react'

interface StatusIconProps {
  status: string
  className?: string
}

export function StatusIcon({ status, className = '' }: StatusIconProps) {
  const iconProps = {
    className: `w-5 h-5 ${className}`,
    strokeWidth: 2
  }

  const renderIcon = () => {
    switch (status) {
      case 'pending':
        return <Clock {...iconProps} />
      case 'in-progress':
        return <Package {...iconProps} />
      case 'completed':
        return <CheckCircle {...iconProps} />
      case 'ready-for-pickup':
        return <Box {...iconProps} />
      case 'shipped':
        return <Truck {...iconProps} />
      default:
        return <Clock {...iconProps} />
    }
  }

  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
    >
      {renderIcon()}
    </motion.div>
  )
}

