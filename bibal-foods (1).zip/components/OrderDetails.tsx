'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Clock, Pencil, Trash2, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Order } from '@/types/orders'

interface OrderDetailsProps {
  order: Order
  onStatusChange: (newStatus: Order['status']) => void
  onAddLot: () => void
  onDelete: () => void
}

export function OrderDetails({ order, onStatusChange, onAddLot, onDelete }: OrderDetailsProps) {
  const [completedBoxes, setCompletedBoxes] = useState(order.products.reduce((sum, p) => sum + p.completed, 0))
  const totalBoxes = order.totalBoxes

  const progress = Math.round((completedBoxes / totalBoxes) * 100)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-sm p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-semibold">{order.clientName}</h3>
          <p className="text-sm text-gray-500">
            {new Date(order.date).toLocaleDateString()} • {order.totalBoxes} cartoni • {order.totalPallets} pedane
          </p>
        </div>
        <div className="flex items-center gap-2">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="px-3 py-1 rounded-full bg-yellow-50 text-yellow-700 text-sm font-medium flex items-center"
          >
            <Clock className="w-4 h-4 mr-1" />
            In attesa
          </motion.div>
          <Button variant="ghost" size="icon">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={onDelete}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {order.status === 'pending' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Button 
            onClick={() => onStatusChange('in-progress')}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Clock className="w-4 h-4 mr-2" />
            Avvia Lavorazione
          </Button>
        </motion.div>
      )}

      <div className="space-y-6">
        <div>
          <h4 className="font-medium mb-2">Cartoni Completati</h4>
          <div className="flex items-center gap-4">
            <Input
              type="number"
              value={completedBoxes}
              onChange={(e) => setCompletedBoxes(parseInt(e.target.value) || 0)}
              className="w-24"
            />
            <span className="text-gray-500">/ {totalBoxes}</span>
          </div>
          <div className="mt-2 bg-gray-100 rounded-full h-2 overflow-hidden">
            <motion.div
              className="h-full bg-purple-600"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-medium">Lotti di Produzione</h4>
            <Button 
              onClick={onAddLot}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi Lotto
            </Button>
          </div>
          {order.lots.length === 0 ? (
            <p className="text-gray-500 text-sm">Nessun lotto registrato</p>
          ) : (
            <div className="space-y-2">
              {order.lots.map((lot, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">Lotto #{lot.number}</p>
                    <p className="text-sm text-gray-500">{new Date(lot.productionDate).toLocaleDateString()}</p>
                  </div>
                  <p className="font-medium">{lot.boxes} cartoni</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}

