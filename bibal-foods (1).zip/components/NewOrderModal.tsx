'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Order } from "@/types/orders"

interface NewOrderModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (orderData: Omit<Order, 'id'>) => void
}

export function NewOrderModal({ isOpen, onClose, onSubmit }: NewOrderModalProps) {
  const [customerName, setCustomerName] = useState('')
  const [agent, setAgent] = useState('')
  const [products, setProducts] = useState<Array<{ name: string; quantity: number }>>([])

  const handleAddProduct = () => {
    setProducts([...products, { name: '', quantity: 0 }])
  }

  const handleProductChange = (index: number, field: 'name' | 'quantity', value: string | number) => {
    const updatedProducts = [...products]
    updatedProducts[index][field] = value
    setProducts(updatedProducts)
  }

  const handleSubmit = () => {
    const newOrder: Omit<Order, 'id'> = {
      customerName,
      date: new Date().toISOString(),
      status: 'pending',
      agent,
      products,
      totalBoxes: products.reduce((sum, product) => sum + product.quantity, 0),
      totalPallets: Math.ceil(products.reduce((sum, product) => sum + product.quantity, 0) / 80),
    }
    onSubmit(newOrder)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nuovo Ordine</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <label htmlFor="customerName" className="text-right">
              Cliente
            </label>
            <Input
              id="customerName"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <label htmlFor="agent" className="text-right">
              Agente
            </label>
            <Select value={agent} onValueChange={setAgent}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Seleziona agente" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="agent1">Agente 1</SelectItem>
                <SelectItem value="agent2">Agente 2</SelectItem>
                {/* Add more agents as needed */}
              </SelectContent>
            </Select>
          </div>
          {products.map((product, index) => (
            <div key={index} className="grid grid-cols-4 items-center gap-4">
              <Input
                placeholder="Nome prodotto"
                value={product.name}
                onChange={(e) => handleProductChange(index, 'name', e.target.value)}
                className="col-span-2"
              />
              <Input
                type="number"
                placeholder="Quantità"
                value={product.quantity}
                onChange={(e) => handleProductChange(index, 'quantity', parseInt(e.target.value))}
              />
              <Button variant="outline" onClick={() => setProducts(products.filter((_, i) => i !== index))}>
                Rimuovi
              </Button>
            </div>
          ))}
          <Button onClick={handleAddProduct}>Aggiungi Prodotto</Button>
        </div>
        <DialogFooter>
          <Button onClick={handleSubmit}>Crea Ordine</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

