import { Order, OrderStatus } from "@/types/orders"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface OrderListProps {
  orders: Order[]
  onUpdateStatus: (orderId: string, newStatus: OrderStatus) => void
}

export function OrderList({ orders, onUpdateStatus }: OrderListProps) {
  const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
    const statusFlow: OrderStatus[] = ['pending', 'in-progress', 'completed', 'ready-for-pickup', 'shipped']
    const currentIndex = statusFlow.indexOf(currentStatus)
    return currentIndex < statusFlow.length - 1 ? statusFlow[currentIndex + 1] : null
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id}>
          <CardHeader>
            <CardTitle>Ordine #{order.id}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-semibold">Cliente:</p>
                <p>{order.customerName}</p>
              </div>
              <div>
                <p className="font-semibold">Data:</p>
                <p>{new Date(order.date).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="font-semibold">Stato:</p>
                <Select
                  value={order.status}
                  onValueChange={(newStatus) => onUpdateStatus(order.id, newStatus as OrderStatus)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">In Attesa</SelectItem>
                    <SelectItem value="in-progress">In Lavorazione</SelectItem>
                    <SelectItem value="completed">Completato</SelectItem>
                    <SelectItem value="ready-for-pickup">Pronto per il Ritiro</SelectItem>
                    <SelectItem value="shipped">Spedito</SelectItem>
                    <SelectItem value="cancelled">Cancellato</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="font-semibold">Agente:</p>
                <p>{order.agent || 'Non assegnato'}</p>
              </div>
            </div>
            <div className="mt-4">
              <p className="font-semibold">Prodotti:</p>
              <ul className="list-disc list-inside">
                {order.products.map((product, index) => (
                  <li key={index}>
                    {product.name} - {product.quantity} pezzi
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-4 flex justify-end">
              {getNextStatus(order.status) && (
                <Button onClick={() => onUpdateStatus(order.id, getNextStatus(order.status)!)}>
                  Avanza a {getNextStatus(order.status)}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

