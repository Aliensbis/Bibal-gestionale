import { Customer, CustomerAnalytics } from '@/types/customer'

interface CustomersListProps {
  customers: Customer[]
  selectedCustomerId: string | null
  onSelectCustomer: (customerId: string) => void
  customerStats: Record<string, CustomerAnalytics>
}

export function CustomersList({ customers, selectedCustomerId, onSelectCustomer, customerStats }: CustomersListProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <h2 className="text-xl font-semibold mb-4">Clienti</h2>
      <div className="space-y-2">
        {customers.map((customer) => (
          <div
            key={customer.id}
            className={`p-2 rounded-md cursor-pointer ${
              customer.id === selectedCustomerId ? 'bg-blue-100' : 'hover:bg-gray-100'
            }`}
            onClick={() => onSelectCustomer(customer.id)}
          >
            <div className="font-medium">{customer.name}</div>
            <div className="text-sm text-gray-500">
              {customerStats[customer.id]?.rank.tier} - {customerStats[customer.id]?.yearly.orders} ordini
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

