import { useState } from 'react'
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Order, OrderStatus } from "@/types/orders"

interface OrderFiltersProps {
  orders: Order[]
  onFilterChange: (filteredOrders: Order[]) => void
}

export function OrderFilters({ orders, onFilterChange }: OrderFiltersProps) {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all')
  const [agentFilter, setAgentFilter] = useState<string>('all')
  const [startDate, setStartDate] = useState<string>('')
  const [endDate, setEndDate] = useState<string>('')

  const applyFilters = () => {
    let filteredOrders = orders

    if (searchTerm) {
      filteredOrders = filteredOrders.filter(order => 
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (statusFilter !== 'all') {
      filteredOrders = filteredOrders.filter(order => order.status === statusFilter)
    }

    if (agentFilter !== 'all') {
      filteredOrders = filteredOrders.filter(order => order.agent === agentFilter)
    }

    if (startDate && endDate) {
      filteredOrders = filteredOrders.filter(order => {
        const orderDate = new Date(order.date)
        return orderDate >= new Date(startDate) && orderDate <= new Date(endDate)
      })
    }

    onFilterChange(filteredOrders)
  }

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
    applyFilters()
  }

  const handleStatusChange = (value: string) => {
    setStatusFilter(value as OrderStatus | 'all')
    applyFilters()
  }

  const handleAgentChange = (value: string) => {
    setAgentFilter(value)
    applyFilters()
  }

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStartDate(e.target.value)
    applyFilters()
  }

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEndDate(e.target.value)
    applyFilters()
  }

  return (
    <div className="flex flex-col md:flex-row gap-4 mb-8">
      <Input
        placeholder="Cerca per nome cliente"
        value={searchTerm}
        onChange={handleSearchChange}
        className="md:w-1/5"
      />
      <Select value={statusFilter} onValueChange={handleStatusChange}>
        <SelectTrigger className="md:w-1/5">
          <SelectValue placeholder="Filtra per stato" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Tutti gli stati</SelectItem>
          <SelectItem value="pending">In Attesa</SelectItem>
          <SelectItem value="in-progress">In Lavorazione</SelectItem>
          <SelectItem value="completed">Completati</SelectItem>
          <SelectItem value="ready-for-pickup">Pronti per il Ritiro</SelectItem>
          <SelectItem value="shipped">Spediti</SelectItem>
          <SelectItem value="cancelled">Cancellati</SelectItem>
        </SelectContent>
      </Select>
      <Select value={agentFilter} onValueChange={handleAgentChange}>
        <SelectTrigger className="md:w-1/5">
          <SelectValue placeholder="Filtra per agente" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Tutti gli agenti</SelectItem>
          <SelectItem value="agent1">Agente 1</SelectItem>
          <SelectItem value="agent2">Agente 2</SelectItem>
          {/* Add more agents as needed */}
        </SelectContent>
      </Select>
      <div className="flex gap-2 md:w-2/5">
        <Input
          type="date"
          value={startDate}
          onChange={handleStartDateChange}
          className="w-full"
          placeholder="Data inizio"
        />
        <Input
          type="date"
          value={endDate}
          onChange={handleEndDateChange}
          className="w-full"
          placeholder="Data fine"
        />
      </div>
    </div>
  )
}

