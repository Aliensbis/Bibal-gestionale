'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, X } from 'lucide-react'
import { useState } from 'react'

export function FloatingHelpButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-16 right-0 w-72 bg-white rounded-lg shadow-lg p-4 mb-4"
          >
            <h3 className="text-lg font-semibold mb-2">Hai bisogno di aiuto?</h3>
            <p className="text-gray-600 mb-4">I nostri operatori sono disponibili per assisterti.</p>
            <button className="w-full bg-[#B8860B] text-white rounded-md py-2 hover:bg-[#9B7209] transition-colors">
              Inizia chat
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-[#B8860B] text-white rounded-full p-3 shadow-lg hover:bg-[#9B7209] transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </motion.button>
    </div>
  )
}

