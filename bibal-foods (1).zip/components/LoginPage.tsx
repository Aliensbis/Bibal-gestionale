'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { AnimatedInput } from './AnimatedInput'
import { AnimatedButton } from './AnimatedButton'

interface LoginPageProps {
  area: 'produzione' | 'amministrazione' | 'agenti'
  icon: React.ReactNode
}

interface User {
  email: string
  password: string
}

export function LoginPage({ area, icon }: LoginPageProps) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isRegistering, setIsRegistering] = useState(false)
  const [users, setUsers] = useState<User[]>([])

  useEffect(() => {
    const savedUsers = localStorage.getItem(`users_${area}`)
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers))
    }
  }, [area])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const user = users.find(u => u.email === email && u.password === password)
    if (user) {
      window.location.href = `/dashboard/${area}`
    } else {
      alert('Email o password non corretti')
    }
  }

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    if (users.some(u => u.email === email)) {
      alert('Un utente con questa email esiste già')
    } else {
      const newUsers = [...users, { email, password }]
      setUsers(newUsers)
      localStorage.setItem(`users_${area}`, JSON.stringify(newUsers))
      alert('Registrazione completata con successo')
      setIsRegistering(false)
    }
  }

  const handleRecoverPassword = () => {
    // In a real application, this would trigger an email or other recovery process
    alert('Una email di recupero password è stata inviata al tuo indirizzo email registrato.')
  }

  const handleChangePassword = () => {
    // In a real application, this would open a form to change the password
    alert('Funzionalità di cambio password non ancora implementata.')
  }

  const areaNames = {
    produzione: 'Produzione',
    amministrazione: 'Amministrazione',
    agenti: 'Agenti'
  }

  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-br from-white to-[#492002]/10 flex flex-col items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div 
        className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8"
        initial={{ y: 20, scale: 0.95 }}
        animate={{ y: 0, scale: 1 }}
        transition={{ delay: 0.2 }}
      >
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Link 
            href="/"
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Torna alla selezione
          </Link>
        </motion.div>

        <motion.div
          className="flex justify-center mb-8"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.4, type: "spring" }}
        >
          {icon}
        </motion.div>

        <motion.h1 
          className="text-2xl font-bold text-center mb-8"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          {isRegistering ? 'Registrazione' : 'Accesso'} Area {areaNames[area]}
        </motion.h1>

        <motion.form 
          onSubmit={isRegistering ? handleRegister : handleSubmit}
          className="space-y-6"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <AnimatedInput
            type="email"
            label="Email"
            id="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <AnimatedInput
            type="password"
            label="Password"
            id="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <AnimatedButton type="submit" className="w-full">
            {isRegistering ? 'Registrati' : 'Accedi'}
          </AnimatedButton>
        </motion.form>

        <div className="mt-4 text-center text-sm">
          <button 
            onClick={() => setIsRegistering(!isRegistering)} 
            className="text-blue-600 hover:underline"
          >
            {isRegistering ? 'Hai già un account? Accedi' : 'Non hai un account? Registrati'}
          </button>
        </div>

        <div className="mt-4 text-center text-xs space-x-4">
          <button 
            onClick={handleRecoverPassword}
            className="text-gray-600 hover:underline"
          >
            Recupera Password
          </button>
          <button 
            onClick={handleChangePassword}
            className="text-gray-600 hover:underline"
          >
            Cambia Password
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}

