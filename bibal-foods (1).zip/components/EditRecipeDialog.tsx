'use client'

import { useState, useEffect } from 'react'
import { Product } from '@/types/production'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface EditRecipeDialogProps {
  recipe: Product | null
  isOpen: boolean
  onClose: () => void
  onSave: (recipeId: string | null, updates: Partial<Product>) => void
  isNewRecipe: boolean
}

const defaultRecipe: Product = {
  id: '',
  name: '',
  cartonsPerBatch: 0,
  category: 'Babà',
  ingredients: {
    flour: { amount: 0, type: 'S' },
    eggs: 0,
    sugar: 0,
    salt: 0,
    yeast: 0,
    margarine: 0,
    e202: 0,
    oil: 0
  }
}

export function EditRecipeDialog({ recipe, isOpen, onClose, onSave, isNewRecipe }: EditRecipeDialogProps) {
  const [editedRecipe, setEditedRecipe] = useState<Product>(defaultRecipe)

  useEffect(() => {
    if (recipe) {
      setEditedRecipe(recipe)
    } else {
      setEditedRecipe(defaultRecipe)
    }
  }, [recipe])

  const handleSave = () => {
    onSave(isNewRecipe ? null : editedRecipe.id, editedRecipe)
    onClose()
  }

  const updateIngredient = (
    key: keyof Product['ingredients'],
    value: number | { amount: number; type: 'S' | 'M' | '0' | 'Bignè' }
  ) => {
    setEditedRecipe(prev => ({
      ...prev,
      ingredients: {
        ...prev.ingredients,
        [key]: value
      }
    }))
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {isNewRecipe ? 'Aggiungi Nuova Ricetta' : 'Modifica Ricetta'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4">
          <div className="grid gap-2">
            <label className="text-sm font-medium">Nome Prodotto</label>
            <Input
              value={editedRecipe.name}
              onChange={(e) => setEditedRecipe(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">Cartoni per Pesata</label>
            <Input
              type="number"
              value={editedRecipe.cartonsPerBatch}
              onChange={(e) => setEditedRecipe(prev => ({ 
                ...prev, 
                cartonsPerBatch: parseInt(e.target.value) || 0 
              }))}
            />
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">Categoria</label>
            <Select
              value={editedRecipe.category}
              onValueChange={(value: 'Babà' | 'Savarè' | 'Bignè') => 
                setEditedRecipe(prev => ({ ...prev, category: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleziona categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Babà">Babà</SelectItem>
                <SelectItem value="Savarè">Savarè</SelectItem>
                <SelectItem value="Bignè">Bignè</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium">Ingredienti</h3>
            
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Farina (kg)</label>
                  <Input
                    type="number"
                    value={editedRecipe.ingredients.flour.amount}
                    onChange={(e) => updateIngredient('flour', {
                      ...editedRecipe.ingredients.flour,
                      amount: parseFloat(e.target.value) || 0
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Tipo Farina</label>
                  <Select
                    value={editedRecipe.ingredients.flour.type}
                    onValueChange={(value: 'S' | 'M' | '0' | 'Bignè') => 
                      updateIngredient('flour', {
                        ...editedRecipe.ingredients.flour,
                        type: value
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="S">S</SelectItem>
                      <SelectItem value="M">M</SelectItem>
                      <SelectItem value="0">0</SelectItem>
                      <SelectItem value="Bignè">Bignè</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {[
                { key: 'eggs', label: 'Uova' },
                { key: 'sugar', label: 'Zucchero' },
                { key: 'salt', label: 'Sale' },
                { key: 'yeast', label: 'Lievito' },
                { key: 'margarine', label: 'Margarina' },
                { key: 'e202', label: 'E202' },
                { key: 'oil', label: 'Olio' }
              ].map(({ key, label }) => (
                <div key={key}>
                  <label className="text-sm font-medium">{label} (kg)</label>
                  <Input
                    type="number"
                    value={editedRecipe.ingredients[key as keyof typeof editedRecipe.ingredients] || 0}
                    onChange={(e) => updateIngredient(
                      key as keyof Product['ingredients'],
                      parseFloat(e.target.value) || 0
                    )}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <Button variant="outline" onClick={onClose}>
            Annulla
          </Button>
          <Button onClick={handleSave} className="bg-purple-600 hover:bg-purple-700">
            {isNewRecipe ? 'Aggiungi Ricetta' : 'Salva Modifiche'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

