'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ProductionLot } from '@/types/orders'

interface LotManagementProps {
  lots: ProductionLot[]
  onAddLot: (lot: Omit<ProductionLot, 'id'>) => void
  onRemoveLot: (lotId: string) => void
}

export function LotManagement({ lots, onAddLot, onRemoveLot }: LotManagementProps) {
  const [isAdding, setIsAdding] = useState(false)
  const [newLot, setNewLot] = useState({
    number: '',
    productionDate: new Date().toISOString().split('T')[0],
    boxes: 0
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddLot(newLot)
    setIsAdding(false)
    setNewLot({
      number: '',
      productionDate: new Date().toISOString().split('T')[0],
      boxes: 0
    })
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-medium">Lotti di Produzione</h3>
        <Button
          onClick={() => setIsAdding(true)}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Aggiungi Lotto
        </Button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="space-y-4 bg-gray-50 p-4 rounded-lg"
          >
            <div className="grid grid-cols-3 gap-4">
              <Input
                placeholder="Numero Lotto"
                value={newLot.number}
                onChange={(e) => setNewLot({ ...newLot, number: e.target.value })}
                required
              />
              <Input
                type="date"
                value={newLot.productionDate}
                onChange={(e) => setNewLot({ ...newLot, productionDate: e.target.value })}
                required
              />
              <Input
                type="number"
                placeholder="Cartoni"
                value={newLot.boxes || ''}
                onChange={(e) => setNewLot({ ...newLot, boxes: parseInt(e.target.value) || 0 })}
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setIsAdding(false)}>
                Annulla
              </Button>
              <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                Aggiungi
              </Button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      <div className="space-y-2">
        {lots.map((lot) => (
          <motion.div
            key={lot.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
          >
            <div>
              <p className="font-medium">Lotto #{lot.number}</p>
              <p className="text-sm text-gray-500">
                {new Date(lot.productionDate).toLocaleDateString()}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-medium">{lot.boxes} cartoni</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onRemoveLot(lot.id)}
                className="text-red-500 hover:text-red-600"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

