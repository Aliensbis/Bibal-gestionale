'use client'

import { motion } from 'framer-motion'
import { COLORS } from '@/utils/constants'

interface AnimatedButtonProps {
  children: React.ReactNode
  onClick?: () => void
  type?: 'button' | 'submit'
  variant?: 'primary' | 'secondary'
  className?: string
}

export function AnimatedButton({ 
  children, 
  onClick, 
  type = 'button',
  variant = 'primary',
  className = ''
}: AnimatedButtonProps) {
  return (
    <motion.button
      type={type}
      onClick={onClick}
      className={`px-6 py-2 rounded-md font-medium ${
        variant === 'primary' 
          ? 'bg-[#B8860B] text-white hover:bg-[#9B7209]' 
          : 'bg-white text-[#B8860B] border border-[#B8860B] hover:bg-[#B8860B]/10'
      } ${className}`}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.button>
  )
}

