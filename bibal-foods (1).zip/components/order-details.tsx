'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Pencil, Trash2, Printer, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Order, ProductionLot } from '@/types/orders'
import { StatusIcon } from '@/components/ui/status-icon'
import { LotManagement } from '@/components/lot-management'

interface OrderDetailsProps {
  order: Order
  onStatusChange: (orderId: string, newStatus: Order['status']) => void
  onUpdate: (orderId: string, updates: Partial<Order>) => void
  onDelete: (orderId: string) => void
  onPrint: (orderId: string, type: 'order' | 'ddt') => void
}

export function OrderDetails({
  order,
  onStatusChange,
  onUpdate,
  onDelete,
  onPrint
}: OrderDetailsProps) {
  const [completedBoxes, setCompletedBoxes] = useState(
    order.products.reduce((sum, p) => sum + p.completed, 0)
  )

  const progress = Math.round((completedBoxes / order.totalBoxes) * 100)

  const handleAddLot = (lot: Omit<ProductionLot, 'id'>) => {
    const newLot: ProductionLot = {
      ...lot,
      id: Date.now().toString()
    }
    onUpdate(order.id, {
      lots: [...order.lots, newLot]
    })
  }

  const handleRemoveLot = (lotId: string) => {
    onUpdate(order.id, {
      lots: order.lots.filter(l => l.id !== lotId)
    })
  }

  const getNextStatus = (currentStatus: Order['status']): Order['status'] | null => {
    const flow: Order['status'][] = ['pending', 'in-progress', 'completed', 'ready-for-pickup', 'shipped']
    const currentIndex = flow.indexOf(currentStatus)
    return currentIndex < flow.length - 1 ? flow[currentIndex + 1] : null
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-white rounded-lg shadow-sm p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-semibold">{order.clientName}</h3>
          <p className="text-sm text-gray-500">
            {new Date(order.date).toLocaleDateString()} • {order.totalBoxes} cartoni • {order.totalPallets} pedane
          </p>
        </div>
        <div className="flex items-center gap-2">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="px-3 py-1 rounded-full bg-gray-100 text-gray-700 text-sm font-medium flex items-center gap-2"
          >
            <StatusIcon status={order.status} />
            {order.status === 'pending' && 'In Attesa'}
            {order.status === 'in-progress' && 'In Lavorazione'}
            {order.status === 'completed' && 'Completato'}
            {order.status === 'ready-for-pickup' && 'Pronto per Ritiro'}
            {order.status === 'shipped' && 'Spedito'}
          </motion.div>
          <Button variant="ghost" size="icon" onClick={() => onPrint(order.id, 'order')}>
            <Printer className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(order.id)}
            className="text-red-500 hover:text-red-600"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h4 className="font-medium mb-2">Avanzamento Produzione</h4>
          <div className="flex items-center gap-4">
            <Input
              type="number"
              value={completedBoxes}
              onChange={(e) => {
                const value = parseInt(e.target.value) || 0
                setCompletedBoxes(value)
                if (value >= order.totalBoxes) {
                  onStatusChange(order.id, 'completed')
                }
              }}
              className="w-24"
            />
            <span className="text-gray-500">/ {order.totalBoxes}</span>
          </div>
          <div className="mt-2 bg-gray-100 rounded-full h-2 overflow-hidden">
            <motion.div
              className="h-full bg-purple-600"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <LotManagement
          lots={order.lots}
          onAddLot={handleAddLot}
          onRemoveLot={handleRemoveLot}
        />

        {order.status === 'completed' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-end"
          >
            <Button
              onClick={() => onPrint(order.id, 'ddt')}
              className="bg-green-600 hover:bg-green-700"
            >
              <FileText className="w-4 h-4 mr-2" />
              Stampa DDT
            </Button>
          </motion.div>
        )}

        {getNextStatus(order.status) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-end"
          >
            <Button
              onClick={() => onStatusChange(order.id, getNextStatus(order.status)!)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <StatusIcon status={getNextStatus(order.status)!} className="mr-2" />
              {order.status === 'pending' && 'Avvia Lavorazione'}
              {order.status === 'in-progress' && 'Segna come Completato'}
              {order.status === 'completed' && 'Segna Pronto per Ritiro'}
              {order.status === 'ready-for-pickup' && 'Segna come Spedito'}
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}

