import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Order } from "@/types/orders"

interface OrderStatsProps {
  orders: Order[]
}

export function OrderStats({ orders }: OrderStatsProps) {
  const totalOrders = orders.length
  const inProgressOrders = orders.filter(order => order.status === 'in-progress').length
  const completedOrders = orders.filter(order => order.status === 'completed').length
  const readyForPickupOrders = orders.filter(order => order.status === 'ready-for-pickup').length
  const shippedOrders = orders.filter(order => order.status === 'shipped').length

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5 mb-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Totale Ordini</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalOrders}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">In Lavorazione</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{inProgressOrders}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Completati</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{completedOrders}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Pronti per il Ritiro</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{readyForPickupOrders}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Spediti</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{shippedOrders}</div>
        </CardContent>
      </Card>
    </div>
  )
}

