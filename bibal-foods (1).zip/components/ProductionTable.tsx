'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Product, ProductionEntry } from '@/types/production'
import { products } from '@/utils/productionData'

interface ProductionTableProps {
  onEntriesChange: (entries: ProductionEntry[]) => void
}

export function ProductionTable({ onEntriesChange }: ProductionTableProps) {
  const [entries, setEntries] = useState<Record<string, { cartons: number; batches: number }>>({})
  const [prevEntries, setPrevEntries] = useState<string>('')

  const calculateBatches = (cartons: number, cartonsPerBatch: number) => {
    return Math.ceil(cartons / cartonsPerBatch)
  }

  const calculateCartons = (batches: number, cartonsPerBatch: number) => {
    return batches * cartonsPerBatch
  }

  const handleCartonsChange = (productId: string, cartons: number, cartonsPerBatch: number) => {
    const batches = calculateBatches(cartons, cartonsPerBatch)
    setEntries(prev => ({
      ...prev,
      [productId]: { cartons, batches }
    }))
  }

  const handleBatchesChange = (productId: string, batches: number, cartonsPerBatch: number) => {
    const cartons = calculateCartons(batches, cartonsPerBatch)
    setEntries(prev => ({
      ...prev,
      [productId]: { cartons, batches }
    }))
  }

  useEffect(() => {
    const currentEntriesString = JSON.stringify(entries)
    if (currentEntriesString !== prevEntries) {
      setPrevEntries(currentEntriesString)
      const productionEntries: ProductionEntry[] = Object.entries(entries).map(([productId, entry]) => {
        const product = products.find(p => p.id === productId)!
        return {
          product: product.name,
          cartons: entry.cartons,
          batches: entry.batches,
          ingredients: {
            flour: product.ingredients.flour.amount * entry.batches,
            eggs: product.ingredients.eggs * entry.batches,
            sugar: product.ingredients.sugar * entry.batches,
            salt: product.ingredients.salt * entry.batches,
            yeast: product.ingredients.yeast * entry.batches,
            margarine: product.ingredients.margarine * entry.batches,
            e202: product.ingredients.e202 ? product.ingredients.e202 * entry.batches : 0,
            oil: product.ingredients.oil ? product.ingredients.oil * entry.batches : 0
          }
        }
      })
      onEntriesChange(productionEntries)
    }
  }, [entries, onEntriesChange, prevEntries])

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-50">
            <th className="border p-2 text-left">Prodotto</th>
            <th className="border p-2 text-left">Categoria</th>
            <th className="border p-2 text-left">Cartoni</th>
            <th className="border p-2 text-left">Pesate</th>
            <th className="border p-2 text-left">Cartoni per Pesata</th>
            <th className="border p-2 text-left">Farina (kg)</th>
            <th className="border p-2 text-left">Uova (kg)</th>
            <th className="border p-2 text-left">Zucchero (kg)</th>
            <th className="border p-2 text-left">Sale (kg)</th>
            <th className="border p-2 text-left">Lievito (kg)</th>
            <th className="border p-2 text-left">Margarina (kg)</th>
            <th className="border p-2 text-left">E202 (kg)</th>
            <th className="border p-2 text-left">Olio (kg)</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => {
            const entry = entries[product.id] || { cartons: 0, batches: 0 }
            return (
              <motion.tr
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="hover:bg-gray-50"
              >
                <td className="border p-2">{product.name}</td>
                <td className="border p-2">{product.category}</td>
                <td className="border p-2">
                  <input
                    type="number"
                    min="0"
                    value={entry.cartons || ''}
                    onChange={(e) => handleCartonsChange(product.id, parseInt(e.target.value) || 0, product.cartonsPerBatch)}
                    className="w-20 p-1 border rounded"
                  />
                </td>
                <td className="border p-2">
                  <input
                    type="number"
                    min="0"
                    value={entry.batches || ''}
                    onChange={(e) => handleBatchesChange(product.id, parseInt(e.target.value) || 0, product.cartonsPerBatch)}
                    className="w-20 p-1 border rounded"
                  />
                </td>
                <td className="border p-2">{product.cartonsPerBatch}</td>
                <td className="border p-2">
                  {(product.ingredients.flour.amount * entry.batches).toFixed(2)}
                </td>
                <td className="border p-2">
                  {(product.ingredients.eggs * entry.batches).toFixed(2)}
                </td>
                <td className="border p-2">
                  {(product.ingredients.sugar * entry.batches).toFixed(2)}
                </td>
                <td className="border p-2">
                  {(product.ingredients.salt * entry.batches).toFixed(2)}
                </td>
                <td className="border p-2">
                  {(product.ingredients.yeast * entry.batches).toFixed(3)}
                </td>
                <td className="border p-2">
                  {(product.ingredients.margarine * entry.batches).toFixed(2)}
                </td>
                <td className="border p-2">
                  {product.ingredients.e202 
                    ? (product.ingredients.e202 * entry.batches).toFixed(4)
                    : '-'
                  }
                </td>
                <td className="border p-2">
                  {product.ingredients.oil
                    ? (product.ingredients.oil * entry.batches).toFixed(2)
                    : '-'
                  }
                </td>
              </motion.tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

