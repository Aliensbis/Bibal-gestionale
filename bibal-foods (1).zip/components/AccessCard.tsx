'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { TypeIcon as type, LucideIcon } from 'lucide-react'

interface AccessCardProps {
  icon: LucideIcon
  title: string
  subtitle: string
  href: string
}

export function AccessCard({ icon: Icon, title, subtitle, href }: AccessCardProps) {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ duration: 0.3 }}
    >
      <Link 
        href={href}
        className="block p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow"
      >
        <motion.div
          whileHover={{ rotate: 5 }}
          className="w-16 h-16 mb-4 mx-auto"
        >
          <Icon size={64} color="#B8860B" />
        </motion.div>
        <h2 className="text-xl font-semibold text-center mb-2">{title}</h2>
        <p className="text-sm text-center text-gray-600">{subtitle}</p>
      </Link>
    </motion.div>
  )
}

