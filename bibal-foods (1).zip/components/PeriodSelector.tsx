interface PeriodSelectorProps {
  selectedPeriod: 'day' | 'week' | 'month'
  onPeriodChange: (period: 'day' | 'week' | 'month') => void
}

export function PeriodSelector({ selectedPeriod, onPeriodChange }: PeriodSelectorProps) {
  return (
    <div className="flex space-x-4">
      {['day', 'week', 'month'].map((period) => (
        <button
          key={period}
          onClick={() => onPeriodChange(period as 'day' | 'week' | 'month')}
          className={`px-4 py-2 rounded-md ${
            selectedPeriod === period ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'
          } transition-colors duration-200`}
        >
          {period === 'day' ? 'Giornaliero' : period === 'week' ? 'Settimanale' : 'Mensile'}
        </button>
      ))}
    </div>
  )
}

