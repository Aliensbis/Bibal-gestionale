'use client'

import { motion } from 'framer-motion'
import { SideNav } from '@/components/SideNav'
import { LazyFloatingHelpButton } from '@/components/LazyComponents'
import { useCallback } from 'react'
import { NotificationBell } from '@/components/NotificationBell'
import { useNotifications } from '@/contexts/NotificationContext'

interface DashboardLayoutProps {
  children: React.ReactNode
  accountType: 'produzione' | 'amministrazione' | 'agenti'
}

export function DashboardLayout({ children, accountType }: DashboardLayoutProps) {
  const { notifications, markAsRead } = useNotifications()
  const memoizedSideNav = useCallback(() => <SideNav accountType={accountType} />, [accountType])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex">
      {memoizedSideNav()}
      <div className="flex-1 ml-0 md:ml-64 transition-all duration-300 ease-in-out">
        <header className="bg-white border-b border-gray-200 p-4 flex justify-between items-center">
          {/* Removed h1 element as requested */}
          <NotificationBell 
            notifications={notifications}
            onNotificationClick={markAsRead}
          />
        </header>
        <motion.main
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-7xl mx-auto px-4 py-8"
        >
          {children}
        </motion.main>
      </div>
      <LazyFloatingHelpButton />
    </div>
  )
}

