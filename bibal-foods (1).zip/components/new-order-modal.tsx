'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { products } from '@/utils/productionData'
import { Order, OrderProduct } from '@/types/orders'

interface NewOrderModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (orderData: Partial<Order>) => void
}

export function NewOrderModal({ isOpen, onClose, onSubmit }: NewOrderModalProps) {
  const [clientName, setClientName] = useState('')
  const [selectedProducts, setSelectedProducts] = useState<OrderProduct[]>([])
  const [notes, setNotes] = useState('')
  //const [agent, setAgent] = useState('')

  const handleAddProduct = () => {
    setSelectedProducts([...selectedProducts, { productId: '', name: '', quantity: 0, completed: 0 }])
  }

  const handleRemoveProduct = (index: number) => {
    setSelectedProducts(selectedProducts.filter((_, i) => i !== index))
  }

  const handleSubmit = () => {
    onSubmit({
      clientName,
      products: selectedProducts,
      notes
      //agent
    })
    onClose()
    // Reset form
    setClientName('')
    setSelectedProducts([])
    setNotes('')
    //setAgent('')
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-lg shadow-xl w-full max-w-2xl p-6 m-4"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Nuovo Ordine</h2>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-1">Cliente</label>
                <Input
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Nome del cliente"
                />
              </div>


              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-semibold">Prodotti</h3>
                  <Button onClick={handleAddProduct} className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Aggiungi Prodotto
                  </Button>
                </div>

                <div className="space-y-4">
                  {selectedProducts.map((product, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex gap-4 items-start"
                    >
                      <Select
                        value={product.productId}
                        onValueChange={(value) => {
                          const newProducts = [...selectedProducts]
                          const selectedProduct = products.find(p => p.id === value)
                          newProducts[index] = {
                            ...newProducts[index],
                            productId: value,
                            name: selectedProduct?.name || ''
                          }
                          setSelectedProducts(newProducts)
                        }}
                      >
                        <SelectTrigger className="flex-1">
                          <SelectValue placeholder="Seleziona prodotto" />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map(p => (
                            <SelectItem key={p.id} value={p.id}>
                              {p.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Input
                        type="number"
                        placeholder="Quantità"
                        className="w-32"
                        value={product.quantity || ''}
                        onChange={(e) => {
                          const newProducts = [...selectedProducts]
                          newProducts[index] = {
                            ...newProducts[index],
                            quantity: parseInt(e.target.value) || 0
                          }
                          setSelectedProducts(newProducts)
                        }}
                      />

                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveProduct(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Note (opzionale)</label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Aggiungi eventuali note..."
                  className="h-32"
                />
              </div>

              <div className="flex justify-end gap-4">
                <Button variant="outline" onClick={onClose}>
                  Annulla
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={!clientName || selectedProducts.length === 0}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Crea Ordine
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

