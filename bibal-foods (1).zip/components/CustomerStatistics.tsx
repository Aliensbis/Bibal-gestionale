import { useState, useEffect } from 'react'
import { ShoppingBag, TrendingUp, Calculator } from 'lucide-react'
import { StatCard } from '@/components/ui/stat-card'
import { CustomerDetails } from '@/components/CustomerDetails'
import { CustomerAnalytics, Order } from '@/types/customer'
import { getCustomerOrders, calculateCustomerMetrics } from '@/utils/customerUtils'
import { formatCurrency } from '@/utils/formatters'

interface CustomerStatisticsProps {
  customerId: string | null
  period: 'week' | 'month' | 'year'
  onPeriodChange: (period: 'week' | 'month' | 'year') => void
  customerStats: CustomerAnalytics
}

export function CustomerStatistics({ customerId, period, onPeriodChange, customerStats }: CustomerStatisticsProps) {
  const [customerOrders, setCustomerOrders] = useState<Order[]>([])
  const [stats, setStats] = useState({
    totalOrders: 0,
    revenue: 0,
    averageOrderValue: 0,
    orderTrend: 0,
    revenueTrend: 0,
    avgOrderTrend: 0,
  })

  useEffect(() => {
    if (customerId) {
      const fetchOrders = async () => {
        const orders = await getCustomerOrders(customerId)
        setCustomerOrders(orders)
        const metrics = calculateCustomerMetrics(orders)
        setStats({
          totalOrders: metrics.totalOrders,
          revenue: metrics.totalRevenue,
          averageOrderValue: metrics.averageOrderValue,
          orderTrend: customerStats?.[period]?.orders ?? 0,
          revenueTrend: customerStats?.[period]?.boxes ?? 0,
          avgOrderTrend: customerStats?.[period]?.trend ?? 0,
        })
      }
      fetchOrders()
    }
  }, [customerId, period, customerStats])

  return (
    <div className="space-y-6">
      <div className="flex space-x-4 mb-6">
        <button 
          onClick={() => onPeriodChange('week')}
          className={`px-4 py-2 rounded-md ${
            period === 'week' ? 'bg-blue-600 text-white' : 'bg-white'
          }`}
        >
          Settimana
        </button>
        <button 
          onClick={() => onPeriodChange('month')}
          className={`px-4 py-2 rounded-md ${
            period === 'month' ? 'bg-blue-600 text-white' : 'bg-white'
          }`}
        >
          Mese
        </button>
        <button 
          onClick={() => onPeriodChange('year')}
          className={`px-4 py-2 rounded-md ${
            period === 'year' ? 'bg-blue-600 text-white' : 'bg-white'
          }`}
        >
          Anno
        </button>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <StatCard
          title="Ordini Totali"
          value={stats.totalOrders}
          trend={stats.orderTrend}
          icon={ShoppingBag}
        />
        <StatCard
          title="Fatturato"
          value={formatCurrency(stats.revenue)}
          trend={stats.revenueTrend}
          icon={TrendingUp}
        />
        <StatCard
          title="Media Ordini"
          value={formatCurrency(stats.averageOrderValue)}
          trend={stats.avgOrderTrend}
          icon={Calculator}
        />
      </div>

      <CustomerDetails
        customerId={customerId}
        orders={customerOrders}
        stats={customerStats ?? {
          weekly: { orders: 0, boxes: 0, trend: 0 },
          monthly: { orders: 0, boxes: 0, trend: 0 },
          yearly: { orders: 0, boxes: 0, trend: 0 },
          rank: { tier: 'Bronze', color: 'text-orange-600', percentile: 0 }
        }}
      />
    </div>
  )
}

