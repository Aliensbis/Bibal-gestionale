'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Factory, Users, BarChart, Package, FileText, ShoppingCart, AlertTriangle, LogOut, Menu, X, Settings, ClipboardCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const navItems = {
  produzione: [
    { icon: Home, label: 'Home', href: '/dashboard/produzione' },
    { icon: Factory, label: 'Produzione', href: '/dashboard/produzione/produzione' },
    { icon: Users, label: 'Clienti', href: '/dashboard/produzione/clienti' },
    { icon: Users, label: 'Personale', href: '/dashboard/produzione/personale' },
    { icon: BarChart, label: 'Statistiche', href: '/dashboard/produzione/statistiche' },
    { icon: Package, label: 'Magazzino', href: '/dashboard/produzione/magazzino' },
    { icon: FileText, label: 'Ordini', href: '/dashboard/produzione/ordini' },
    { icon: ShoppingCart, label: 'Acquisti', href: '/dashboard/produzione/acquisti' },
    { icon: AlertTriangle, label: 'Reclami', href: '/dashboard/produzione/reclami' },
    { icon: ClipboardCheck, label: 'HACCP', href: '/dashboard/produzione/haccp' },
  ],
  amministrazione: [
    { icon: Home, label: 'Home', href: '/dashboard/amministrazione' },
    { icon: BarChart, label: 'Statistiche', href: '/dashboard/amministrazione/statistiche' },
    { icon: FileText, label: 'Ordini', href: '/dashboard/amministrazione/ordini' },
    { icon: Users, label: 'Clienti', href: '/dashboard/amministrazione/clienti' },
    { icon: Users, label: 'Agenti', href: '/dashboard/amministrazione/agenti' },
    { icon: AlertTriangle, label: 'Reclami', href: '/dashboard/amministrazione/reclami' },
    { icon: FileText, label: 'Ricette', href: '/dashboard/amministrazione/ricette' },
    { icon: Settings, label: 'Impostazioni', href: '/dashboard/amministrazione/impostazioni' },
  ],
  agenti: [
    { icon: Home, label: 'Home', href: '/dashboard/agenti' },
    { icon: Users, label: 'Clienti', href: '/dashboard/agenti/clienti' },
    { icon: FileText, label: 'Ordini', href: '/dashboard/agenti/ordini' },
    { icon: BarChart, label: 'Statistiche', href: '/dashboard/agenti/statistiche' },
    { icon: AlertTriangle, label: 'Reclami', href: '/dashboard/agenti/reclami' },
    { icon: Settings, label: 'Impostazioni', href: '/dashboard/agenti/impostazioni' },
  ],
}

interface SideNavProps {
  accountType: 'produzione' | 'amministrazione' | 'agenti'
}

export function SideNav({ accountType }: SideNavProps) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      <nav
        className={cn(
          "fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto z-40 transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center mb-6 pt-4">
            {accountType === 'produzione' && <Factory className="w-8 h-8 text-[#492002] mr-2" />}
            {accountType === 'amministrazione' && <Settings className="w-8 h-8 text-[#492002] mr-2" />}
            {accountType === 'agenti' && <Users className="w-8 h-8 text-[#492002] mr-2" />}
            <span className="text-lg font-semibold text-[#492002] capitalize">{accountType}</span>
          </div>
          <div className="space-y-4 flex-grow mt-2">
            {navItems[accountType]?.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors",
                    isActive
                      ? "bg-[#492002]/10 text-[#492002]"
                      : "text-gray-600 hover:bg-[#492002]/5 hover:text-[#492002]"
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.label}
                </Link>
              )
            })}
          </div>
          <Button
            variant="ghost"
            className="mt-auto w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => window.location.href = '/'}
          >
            <LogOut className="w-5 h-5 mr-3" />
            Esci
          </Button>
        </div>
      </nav>
    </>
  )
}

