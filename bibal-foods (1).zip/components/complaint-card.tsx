'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Complaint, ComplaintStatus } from '@/types/complaints'
import { getSeverityColor, getStatusColor } from '@/utils/complaintUtils'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { AlertTriangle, AlertCircle } from 'lucide-react'

interface ComplaintCardProps {
  complaint: Complaint
  onStatusChange: (id: string, status: ComplaintStatus) => void
  onResolution: (id: string, resolution: string) => void
}

export function ComplaintCard({ complaint, onStatusChange, onResolution }: ComplaintCardProps) {
  const [resolution, setResolution] = useState('')
  const [isResolving, setIsResolving] = useState(false)

  const handleStatusChange = (status: ComplaintStatus) => {
    onStatusChange(complaint.id, status)
  }

  const handleResolutionSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onResolution(complaint.id, resolution)
    setResolution('')
    setIsResolving(false)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-white">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl font-normal">
            Reclamo #{complaint.id}
          </CardTitle>
          <CardDescription className="text-base text-gray-500">
            {new Date(complaint.createdAt).toLocaleDateString('it-IT', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </CardDescription>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            <span className="text-orange-500 font-medium">
              {complaint.severity.charAt(0).toUpperCase() + complaint.severity.slice(1)}
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="text-base font-medium mb-1">Cliente</h3>
            <p>#{complaint.customerId}</p>
          </div>
          <div>
            <h3 className="text-base font-medium mb-1">Descrizione</h3>
            <p>{complaint.description}</p>
          </div>
          {complaint.images.length > 0 && (
            <div className="grid grid-cols-2 gap-4 mb-4">
              {complaint.images.map((image, index) => (
                <Dialog key={index}>
                  <DialogTrigger>
                    <img
                      src={image}
                      alt={`Complaint evidence ${index + 1}`}
                      className="rounded-lg cursor-pointer"
                    />
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl">
                    <DialogHeader>
                      <DialogTitle>Immagine {index + 1}</DialogTitle>
                      <DialogDescription>
                        Evidenza per il reclamo #{complaint.id}
                      </DialogDescription>
                    </DialogHeader>
                    <img src={image} alt={`Complaint evidence ${index + 1}`} className="w-full" />
                  </DialogContent>
                </Dialog>
              ))}
            </div>
          )}
          {/* <div className={`inline-block px-2 py-1 rounded-full text-sm ${getStatusColor(complaint.status)}`}>
            {complaint.status}
          </div> */}
        </CardContent>
        <CardFooter className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 text-yellow-600">
              <AlertCircle className="h-5 w-5" />
              <span>In attesa</span>
            </div>
          </div>
          {complaint.status === 'pending' && (
            <Button
              variant="link"
              className="text-blue-600 hover:text-blue-700"
              onClick={() => handleStatusChange('in-progress')}
            >
              Prendi in carico
            </Button>
          )}
        </CardFooter>
      </Card>
      {isResolving && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          onSubmit={handleResolutionSubmit}
          className="mt-4 space-y-4"
        >
          <Textarea
            value={resolution}
            onChange={(e) => setResolution(e.target.value)}
            placeholder="Descrivi la soluzione..."
            required
          />
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => setIsResolving(false)}>
              Annulla
            </Button>
            <Button type="submit">
              Conferma Risoluzione
            </Button>
          </div>
        </motion.form>
      )}
    </motion.div>
  )
}

