export interface Customer {
  id: string
  name: string
}

export interface Order {
  id: string
  date: string
  total: number
  status: 'pending' | 'in-progress' | 'completed'
  boxes?: number
}

export interface CustomerAnalytics {
  weekly: {
    orders: number
    boxes: number
    trend: number
  }
  monthly: {
    orders: number
    boxes: number
    trend: number
  }
  yearly: {
    orders: number
    boxes: number
    trend: number
  }
  rank: {
    tier: 'Premium' | 'Gold' | 'Silver' | 'Bronze'
    color: string
    percentile: number
  }
}

