export type OrderStatus = 
  | 'pending'
  | 'in-progress'
  | 'completed'
  | 'ready-for-pickup'
  | 'shipped'
  | 'cancelled'

export interface Order {
  id: string
  customerName: string
  date: string
  status: OrderStatus
  agent?: string
  products: Array<{ name: string; quantity: number }>
  totalBoxes: number
  totalPallets: number
}

