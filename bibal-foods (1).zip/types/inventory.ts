export interface Product {
  id: string
  name: string
  cartonsPerBatch: number
}

export interface InventoryMovement {
  id: string
  date: string
  productId: string
  type: 'in' | 'out'
  quantity: number
  note?: string
}

