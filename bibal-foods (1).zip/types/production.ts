export interface Product {
  id: string
  name: string
  cartonsPerBatch: number
  ingredients: {
    flour: { amount: number; type: 'S' | 'M' | '0' | 'Bignè' }
    eggs: number
    sugar: number
    salt: number
    yeast: number
    margarine: number
    e202?: number
    oil?: number
  }
  category: 'Babà' | 'Savarè' | 'Bignè'
}

export interface ProductionEntry {
  product: string
  cartons: number
  batches: number
  ingredients: {
    flour: number
    eggs: number
    sugar: number
    salt: number
    yeast: number
    margarine: number
    e202?: number
    oil?: number
  }
}

export interface DailyProduction {
  date: string
  notes?: string
  entries: ProductionEntry[]
  totals: {
    cartons: number
    batches: number
    ingredients: {
      flourS: number
      flourM: number
      flour0: number
      flourBigne: number
      eggs: number
      sugar: number
      salt: number
      yeast: number
      margarine: number
      e202: number
      oil: number
    }
    flourBags: {
      S: number
      M: number
      '0': number
      Bigne: number
    }
    eggCartons: number
  }
}

