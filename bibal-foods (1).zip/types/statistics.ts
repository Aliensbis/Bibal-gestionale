export interface OrderStats {
  weekly: {
    count: number
    total: number
    trend: number
  }
  monthly: {
    count: number
    total: number
    trend: number
  }
  yearly: {
    count: number
    total: number
    trend: number
  }
}

export interface ClientStats {
  id: string
  name: string
  orders: number
  boxes: number
  classification: 'Bronze' | 'Silver' | 'Gold' | 'Premium'
  stats: OrderStats
}

export interface OrderHistoryItem {
  id: string
  date: string
  boxes: number
  products: Array<{
    id: string
    name: string
    boxes: number
    cartonsPerBatch: number
    batches: number
  }>
  status: 'pending' | 'in-progress' | 'completed'
}

