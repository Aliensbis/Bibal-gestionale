'use client'

import { Factory, Settings, Users } from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

const areas = [
  {
    icon: Factory,
    title: 'Produzione',
    subtitle: 'Area Operativa',
    href: '/login/produzione'
  },
  {
    icon: Settings,
    title: 'Amministrazione',
    subtitle: 'Area Gestionale',
    href: '/login/amministrazione'
  },
  {
    icon: Users,
    title: 'Agenti',
    subtitle: 'Area Commerciale',
    href: '/login/agenti'
  }
]

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-[#492002]/10 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-bold text-[#B8860B] mb-2">
          Benvenuto in <span className="text-[#492002]">Bibal Foods</span>
        </h1>
        <p className="text-gray-600 text-lg">
          Seleziona l&apos;area di accesso
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl w-full">
        {areas.map((area, index) => (
          <motion.div
            key={area.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.5, 
              delay: index * 0.1,
              type: "spring",
              stiffness: 100,
              damping: 10
            }}
          >
            <Link
              href={area.href}
              className="block p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:bg-[#492002]/5"
            >
              <div className="flex flex-col items-center">
                <motion.div
                  className="w-16 h-16"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1, rotate: 0 }}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ 
                    type: "spring",
                    stiffness: 260,
                    damping: 20 
                  }}
                >
                  <area.icon className="w-full h-full text-[#492002]" />
                </motion.div>
                <h2 className="text-2xl font-semibold text-[#492002] mb-1">
                  {area.title}
                </h2>
                <p className="text-gray-500">{area.subtitle}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

