import { Settings } from 'lucide-react'
import { LoginPage } from '@/components/LoginPage'

export default function AmministrazionePage() {
  return (
    <LoginPage 
      area="amministrazione" 
      icon={<Settings size={48} className="text-[#B8860B]" />} 
    />
  )
}

