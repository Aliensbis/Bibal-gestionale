import { Factory } from 'lucide-react'
import { LoginPage } from '@/components/LoginPage'

export default function ProduzionePage() {
  return (
    <LoginPage 
      area="produzione" 
      icon={<Factory size={48} className="text-[#B8860B]" />} 
    />
  )
}

