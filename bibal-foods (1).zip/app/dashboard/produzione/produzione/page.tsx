'use client'

import { useState, useCallback } from 'react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { ProductionTable } from '@/components/ProductionTable'
import { LazyProductionSummary } from '@/components/LazyComponents'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { ProductionEntry } from '@/types/production'
import { saveProduction } from '@/utils/productionStorage'
import { useToast } from "@/components/ui/use-toast"

export default function ProduzionePage() {
  const { toast } = useToast()
  const [productionEntries, setProductionEntries] = useState<ProductionEntry[]>([])
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [notes, setNotes] = useState('')

  const handleEntriesChange = useCallback((entries: ProductionEntry[]) => {
    setProductionEntries(entries)
  }, [])

  const handleSaveProduction = async () => {
    try {
      const productionData = {
        date,
        notes,
        entries: productionEntries,
        totals: calculateTotals(productionEntries)
      }
      await saveProduction(productionData)
      toast({
        title: "Successo",
        description: "Produzione salvata con successo!",
      })
    } catch (error) {
      console.error('Errore durante il salvataggio della produzione:', error)
      toast({
        title: "Errore",
        description: "Errore durante il salvataggio della produzione",
        variant: "destructive",
      })
    }
  }

  const calculateTotals = (entries: ProductionEntry[]) => {
    return entries.reduce((acc, entry) => {
      acc.cartons += entry.cartons
      acc.batches += entry.batches
      Object.keys(entry.ingredients).forEach(key => {
        acc.ingredients[key] = (acc.ingredients[key] || 0) + entry.ingredients[key]
      })
      return acc
    }, { cartons: 0, batches: 0, ingredients: {} })
  }

  return (
    <DashboardLayout accountType="produzione">
      <h1 className="text-2xl font-bold mb-6">Gestione Produzione Giornaliera</h1>
      
      <ProductionTable onEntriesChange={handleEntriesChange} />
      
      <div className="mt-8">
        <LazyProductionSummary entries={productionEntries} />
      </div>

      <div className="mt-8 mb-6 flex gap-4">
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Data</label>
          <Input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-48"
          />
        </div>
        <div className="flex-grow">
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">Note</label>
          <Textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Aggiungi eventuali note sulla produzione..."
            className="h-10"
          />
        </div>
      </div>

      <div className="mt-4 flex justify-end">
        <Button onClick={handleSaveProduction} className="bg-purple-600 hover:bg-purple-700">
          Salva Produzione
        </Button>
      </div>
    </DashboardLayout>
  )
}

