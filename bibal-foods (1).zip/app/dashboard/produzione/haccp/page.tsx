'use client'

import { useState } from 'react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import InnovativeProductionForm from './InnovativeProductionForm'

export default function HACCPPage() {
  const [showProductionForm, setShowProductionForm] = useState(false)

  return (
    <DashboardLayout accountType="produzione">
      <div className="mb-8">
        <Link 
          href="/dashboard/produzione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <h1 className="text-2xl font-bold mb-6">Controllo HACCP</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Moduli accettazione</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={() => setShowProductionForm(!showProductionForm)}>
            {showProductionForm ? 'Nascondi' : 'Mostra'} Scheda Produzione Babà
          </Button>
          {showProductionForm && (
            <div className="mt-4">
              <InnovativeProductionForm />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add other HACCP-related content here */}
    </DashboardLayout>
  )
}

