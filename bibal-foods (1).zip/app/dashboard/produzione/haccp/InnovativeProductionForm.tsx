'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, CheckCircle2, XCircle, Save, Printer, Plus, Minus } from 'lucide-react'
import { useToast } from "@/components/ui/use-toast"

export default function InnovativeProductionForm() {
  const [formData, setFormData] = useState({
    date: '19/12/2024',
    ingredients: [{}, {}, {}, {}, {}],
    packaging: [{}, {}],
    products: [{}, {}, {}],
    preChecks: {},
    postChecks: {},
    notes: '',
    signature: 'Fabio La Rosa'
  })
  const { toast } = useToast()

  useEffect(() => {
    const savedData = localStorage.getItem('productionFormData')
    if (savedData) {
      setFormData(JSON.parse(savedData))
    }
  }, [])

  const handleInputChange = (section, index, field, value) => {
    setFormData(prev => {
      const newData = { ...prev }
      newData[section][index] = { ...newData[section][index], [field]: value }
      return newData
    })
  }

  const handleCheckChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }))
  }

  const handleSave = () => {
    localStorage.setItem('productionFormData', JSON.stringify(formData))
    toast({
      title: "Scheda salvata",
      description: "I dati della scheda sono stati salvati con successo.",
    })
  }

  const handlePrint = () => {
    window.print()
  }

  const addRow = (section) => {
    setFormData(prev => ({
      ...prev,
      [section]: [...prev[section], {}]
    }))
  }

  const removeRow = (section, index) => {
    setFormData(prev => ({
      ...prev,
      [section]: prev[section].filter((_, i) => i !== index)
    }))
  }

  return (
    <div className="container mx-auto p-4 space-y-4 print:p-0 print:space-y-1">
      <Card className="print:shadow-none print:border-none">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 print:pb-0">
          <CardTitle>Scheda produzione Babà</CardTitle>
          <div className="flex items-center space-x-2">
            <CalendarIcon className="h-4 w-4 opacity-70" />
            <Input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
              className="w-40"
            />
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">S1 ed1 r1 del 11/01/2024</p>
          <p className="text-sm italic mt-2">
            la data delle farine è relativa al giorno di macinazione, ed è possibile consumarla entro 9 mesi da tale data
          </p>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardHeader className="flex justify-between items-center">
          <CardTitle>Tracciabilità ingredienti</CardTitle>
          <Button onClick={() => addRow('ingredients')} className="print:hidden"><Plus className="h-4 w-4" /></Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[18%]">Ingredienti</TableHead>
                <TableHead className="w-[18%]">Fornitore</TableHead>
                <TableHead className="w-[18%]">Lotto</TableHead>
                <TableHead className="w-[18%]">TMC/Scadenza</TableHead>
                <TableHead className="w-[18%]">Qtà usata</TableHead>
                <TableHead className="w-[10%] print:hidden"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {formData.ingredients.map((ingredient, i) => (
                <TableRow key={i}>
                  <TableCell><Input value={ingredient.name || ''} onChange={(e) => handleInputChange('ingredients', i, 'name', e.target.value)} /></TableCell>
                  <TableCell><Input value={ingredient.supplier || ''} onChange={(e) => handleInputChange('ingredients', i, 'supplier', e.target.value)} /></TableCell>
                  <TableCell><Input value={ingredient.lot || ''} onChange={(e) => handleInputChange('ingredients', i, 'lot', e.target.value)} /></TableCell>
                  <TableCell><Input type="date" value={ingredient.expiry || ''} onChange={(e) => handleInputChange('ingredients', i, 'expiry', e.target.value)} /></TableCell>
                  <TableCell><Input value={ingredient.quantity || ''} onChange={(e) => handleInputChange('ingredients', i, 'quantity', e.target.value)} /></TableCell>
                  <TableCell className="print:hidden">
                    <Button variant="ghost" onClick={() => removeRow('ingredients', i)}><Minus className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardContent className="grid grid-cols-3 gap-4">
          <div>
            <Label>Setacciatura farina</Label>
            <RadioGroup value={formData.preChecks.setacciatura || 'ok'} onValueChange={(value) => handleCheckChange('preChecks', 'setacciatura', value)} className="flex space-x-2 mt-2">
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="setacciaturaOk" value="ok" />
                <Label htmlFor="setacciaturaOk">OK</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="setacciaturaKo" value="ko" />
                <Label htmlFor="setacciaturaKo">KO</Label>
              </div>
            </RadioGroup>
          </div>
          <div>
            <Label>Corpi estranei</Label>
            <RadioGroup value={formData.preChecks.corpiEstranei || 'ok'} onValueChange={(value) => handleCheckChange('preChecks', 'corpiEstranei', value)} className="flex space-x-2 mt-2">
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="corpiEstraneiOk" value="ok" />
                <Label htmlFor="corpiEstraneiOk">OK</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="corpiEstraneiKo" value="ko" />
                <Label htmlFor="corpiEstraneiKo">KO</Label>
              </div>
            </RadioGroup>
          </div>
          <div>
            <Label>Integrità</Label>
            <RadioGroup value={formData.preChecks.integrita || 'ok'} onValueChange={(value) => handleCheckChange('preChecks', 'integrita', value)} className="flex space-x-2 mt-2">
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="integritaOk" value="ok" />
                <Label htmlFor="integritaOk">OK</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem id="integritaKo" value="ko" />
                <Label htmlFor="integritaKo">KO</Label>
              </div>
            </RadioGroup>
          </div>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardHeader className="flex justify-between items-center">
          <CardTitle>Tracciabilità imballaggi primari</CardTitle>
          <Button onClick={() => addRow('packaging')} className="print:hidden"><Plus className="h-4 w-4" /></Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[18%]">Imballaggio</TableHead>
                <TableHead className="w-[18%]">Fornitore</TableHead>
                <TableHead className="w-[18%]">Lotto</TableHead>
                <TableHead className="w-[18%]">TMC</TableHead>
                <TableHead className="w-[18%]">Qtà usata</TableHead>
                <TableHead className="w-[10%] print:hidden"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {formData.packaging.map((pack, i) => (
                <TableRow key={i}>
                  <TableCell><Input value={pack.name || ''} onChange={(e) => handleInputChange('packaging', i, 'name', e.target.value)} /></TableCell>
                  <TableCell><Input value={pack.supplier || ''} onChange={(e) => handleInputChange('packaging', i, 'supplier', e.target.value)} /></TableCell>
                  <TableCell><Input value={pack.lot || ''} onChange={(e) => handleInputChange('packaging', i, 'lot', e.target.value)} /></TableCell>
                  <TableCell><Input type="date" value={pack.expiry || ''} onChange={(e) => handleInputChange('packaging', i, 'expiry', e.target.value)} /></TableCell>
                  <TableCell><Input value={pack.quantity || ''} onChange={(e) => handleInputChange('packaging', i, 'quantity', e.target.value)} /></TableCell>
                  <TableCell className="print:hidden">
                    <Button variant="ghost" onClick={() => removeRow('packaging', i)}><Minus className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardHeader className="flex justify-between items-center">
          <CardTitle>Prodotti realizzati</CardTitle>
          <Button onClick={() => addRow('products')} className="print:hidden"><Plus className="h-4 w-4" /></Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[18%]">Nome prodotto</TableHead>
                <TableHead className="w-[18%]">Formato</TableHead>
                
<TableHead className="w-[18%]">Lotto</TableHead>
                <TableHead className="w-[18%]">TMC</TableHead>
                <TableHead className="w-[18%]">Qtà prodotta</TableHead>
                <TableHead className="w-[10%] print:hidden"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {formData.products.map((product, i) => (
                <TableRow key={i}>
                  <TableCell><Input value={product.name || ''} onChange={(e) => handleInputChange('products', i, 'name', e.target.value)} /></TableCell>
                  <TableCell><Input value={product.format || ''} onChange={(e) => handleInputChange('products', i, 'format', e.target.value)} /></TableCell>
                  <TableCell><Input value={product.lot || ''} onChange={(e) => handleInputChange('products', i, 'lot', e.target.value)} /></TableCell>
                  <TableCell><Input type="date" value={product.expiry || ''} onChange={(e) => handleInputChange('products', i, 'expiry', e.target.value)} /></TableCell>
                  <TableCell><Input value={product.quantity || ''} onChange={(e) => handleInputChange('products', i, 'quantity', e.target.value)} /></TableCell>
                  <TableCell className="print:hidden">
                    <Button variant="ghost" onClick={() => removeRow('products', i)}><Minus className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardHeader>
          <CardTitle>Controlli operativi</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold mb-2">Controlli preoperativi</h3>
            {[
              'I macchinari sono integri',
              'Il personale indossa divise pulite', 
              'Non vi sono fonti di corpi estranei',
              'Le superfici sono sanificate',
              'Assenza di animali infestanti'
            ].map((text, i) => (
              <div key={i} className="flex items-center justify-between py-1">
                <span className="text-sm">{text}</span>
                <RadioGroup value={formData.preChecks[`check${i}`] || 'ok'} onValueChange={(value) => handleCheckChange('preChecks', `check${i}`, value)} className="flex space-x-2">
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem id={`preOk${i}`} value="ok" />
                    <Label htmlFor={`preOk${i}`}><CheckCircle2 className="h-4 w-4 text-green-500" /></Label>
                  </div>
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem id={`preKo${i}`} value="ko" />
                    <Label htmlFor={`preKo${i}`}><XCircle className="h-4 w-4 text-red-500" /></Label>
                  </div>
                </RadioGroup>
              </div>
            ))}
          </div>
          <div>
            <h3 className="font-semibold mb-2">Controlli postoperativi</h3>
            {[
              'I macchinari sono integri',
              'Non sono stati introdotti allergeni fuori controllo',
              'Non si sono verificate rotture di materiali fragili'
            ].map((text, i) => (
              <div key={i} className="flex items-center justify-between py-1">
                <span className="text-sm">{text}</span>
                <RadioGroup value={formData.postChecks[`check${i}`] || 'ok'} onValueChange={(value) => handleCheckChange('postChecks', `check${i}`, value)} className="flex space-x-2">
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem id={`postOk${i}`} value="ok" />
                    <Label htmlFor={`postOk${i}`}><CheckCircle2 className="h-4 w-4 text-green-500" /></Label>
                  </div>
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem id={`postKo${i}`} value="ko" />
                    <Label htmlFor={`postKo${i}`}><XCircle className="h-4 w-4 text-red-500" /></Label>
                  </div>
                </RadioGroup>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="print:shadow-none print:border-none">
        <CardHeader>
          <CardTitle>Note</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea 
            placeholder="Inserisci eventuali note qui..." 
            className="min-h-[60px]"
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          />
        </CardContent>
      </Card>

      <div className="flex justify-between items-center print:flex-col print:items-start">
        <div className="flex items-center space-x-2">
          <div className="text-sm font-medium">Firma Resp. Produzione</div>
          <Input 
            className="w-60" 
            value={formData.signature}
            onChange={(e) => setFormData(prev => ({ ...prev, signature: e.target.value }))}
          />
        </div>
        <div className="space-x-2 print:hidden">
          <Button onClick={handleSave} className="bg-green-500 hover:bg-green-600">
            <Save className="mr-2 h-4 w-4" /> Salva Scheda
          </Button>
          <Button onClick={handlePrint} variant="outline">
            <Printer className="mr-2 h-4 w-4" /> Stampa
          </Button>
        </div>
      </div>
    </div>
  )
}

