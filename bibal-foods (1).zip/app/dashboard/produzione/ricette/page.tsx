'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { products } from '@/utils/productionData'

export default function RicettePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [category, setCategory] = useState('all')

  const filteredProducts = products.filter(product => 
    (category === 'all' || product.category === category) &&
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Ricette</h1>
            <div className="flex space-x-4">
              <Input
                type="text"
                placeholder="Cerca ricetta..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
              <Select
                value={category}
                onValueChange={setCategory}
                options={[
                  { value: 'all', label: 'Tutte le categorie' },
                  { value: 'Babà', label: 'Babà' },
                  { value: 'Savarè', label: 'Savarè' },
                  { value: 'Bignè', label: 'Bignè' },
                ]}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                className="bg-white p-6 rounded-lg shadow-md"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
                <p className="text-gray-600 mb-2">Categoria: {product.category}</p>
                <p className="text-gray-600 mb-4">Cartoni per pesata: {product.cartonsPerBatch}</p>
                <h3 className="font-medium mb-2">Ingredienti:</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li>Farina {product.ingredients.flour.type}: {product.ingredients.flour.amount} kg</li>
                  <li>Uova: {product.ingredients.eggs} kg</li>
                  <li>Zucchero: {product.ingredients.sugar} kg</li>
                  <li>Sale: {product.ingredients.salt} kg</li>
                  <li>Lievito: {product.ingredients.yeast} kg</li>
                  <li>Margarina: {product.ingredients.margarine} kg</li>
                  {product.ingredients.e202 && <li>E202: {product.ingredients.e202} kg</li>}
                  {product.ingredients.oil && <li>Olio: {product.ingredients.oil} kg</li>}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  )
}

