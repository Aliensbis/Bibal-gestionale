'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Package, Clock, CheckCircle, Box, Truck, Search, Plus, Trash2, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { DashboardLayout } from '@/components/DashboardLayout'
import { StatCard } from '@/components/ui/stat-card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { OrderDetails } from '@/components/order-details'
import { NewOrderModal } from '@/components/new-order-modal'
import { Order } from '@/types/orders'
import { toast } from 'react-hot-toast'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export default function OrdiniPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [agentFilter, setAgentFilter] = useState('all')
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false)
  const [orders, setOrders] = useState<Order[]>([])

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.clientName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter
    const matchesAgent = agentFilter === 'all' || order.agent === agentFilter
    return matchesSearch && matchesStatus && matchesAgent
  })

  const stats = {
    total: orders.length,
    totalBoxes: orders.reduce((sum, order) => sum + order.totalBoxes, 0),
    totalPallets: orders.reduce((sum, order) => sum + order.totalPallets, 0),
    inProgress: orders.filter(o => o.status === 'in-progress').length,
    completed: orders.filter(o => o.status === 'completed').length,
    readyForPickup: orders.filter(o => o.status === 'ready-for-pickup').length,
    shipped: orders.filter(o => o.status === 'shipped').length
  }

  const handleNewOrder = (orderData: Partial<Order>) => {
    const newOrder: Order = {
      id: Date.now().toString(),
      clientName: orderData.clientName || '',
      date: new Date().toISOString(),
      status: 'pending',
      products: orderData.products || [],
      lots: [],
      totalBoxes: orderData.products?.reduce((sum, p) => sum + p.quantity, 0) || 0,
      totalPallets: Math.ceil((orderData.products?.reduce((sum, p) => sum + p.quantity, 0) || 0) / 80),
      notes: orderData.notes,
      agent: orderData.agent
    }
    setOrders([newOrder, ...orders])
    toast.success('Ordine creato con successo!')
  }

  const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ))
    toast.success('Stato ordine aggiornato!')
  }

  const handleUpdateOrder = (orderId: string, updates: Partial<Order>) => {
    setOrders(orders.map(order =>
      order.id === orderId ? { ...order, ...updates } : order
    ))
    toast.success('Ordine aggiornato!')
  }

  const handleDeleteOrder = (orderId: string) => {
    if (confirm('Sei sicuro di voler eliminare questo ordine?')) {
      setOrders(orders.filter(o => o.id !== orderId))
      toast.success('Ordine eliminato!')
    }
  }

  const handlePrint = (orderId: string, type: 'order' | 'ddt') => {
    const order = orders.find(o => o.id === orderId)
    if (!order) return

    // In a real application, this would trigger a print dialog with the order details
    toast.success(`Stampa ${type === 'order' ? 'ordine' : 'DDT'} avviata!`)
  }

  const handleResetHistory = () => {
    if (confirm('Sei sicuro di voler azzerare lo storico? Questa azione non può essere annullata.')) {
      setOrders([])
      toast.success('Storico azzerato!')
    }
  }

  return (
    <DashboardLayout accountType="produzione">
      <div className="mb-8">
        <Link 
          href="/dashboard/produzione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <Package className="h-8 w-8 text-purple-600 mr-2" />
          <h1 className="text-2xl font-bold">Gestione Ordini</h1>
        </div>
        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={handleResetHistory}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Azzera Storico
          </Button>
          <Button
            onClick={() => setIsNewOrderModalOpen(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuovo Ordine
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Cerca cliente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div className="flex gap-4">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Tutti gli stati" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti gli stati</SelectItem>
              <SelectItem value="pending">In Attesa</SelectItem>
              <SelectItem value="in-progress">In Lavorazione</SelectItem>
              <SelectItem value="completed">Completati</SelectItem>
              <SelectItem value="ready-for-pickup">Pronti per il Ritiro</SelectItem>
              <SelectItem value="shipped">Spediti</SelectItem>
            </SelectContent>
          </Select>

          <Select value={agentFilter} onValueChange={setAgentFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Tutti gli agenti" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti gli agenti</SelectItem>
              <SelectItem value="agent1">Agente 1</SelectItem>
              <SelectItem value="agent2">Agente 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        <StatCard
          title="Ordini Totali"
          value={stats.total}
          icon={Package}
          color="text-purple-600"
          subtitle={`${stats.totalBoxes} cartoni - ${stats.totalPallets} pedane`}
        />
        <StatCard
          title="In Lavorazione"
          value={stats.inProgress}
          icon={Clock}
          color="text-blue-600"
        />
        <StatCard
          title="Completati"
          value={stats.completed}
          icon={CheckCircle}
          color="text-green-600"
        />
        <StatCard
          title="Pronti per il Ritiro"
          value={stats.readyForPickup}
          icon={Box}
          color="text-orange-600"
        />
        <StatCard
          title="Spediti"
          value={stats.shipped}
          icon={Truck}
          color="text-purple-600"
        />
      </div>

      <div className="space-y-4">
        {filteredOrders.map((order) => (
          <OrderDetails
            key={order.id}
            order={order}
            onStatusChange={handleStatusChange}
            onUpdate={handleUpdateOrder}
            onDelete={handleDeleteOrder}
            onPrint={handlePrint}
          />
        ))}

        {filteredOrders.length === 0 && (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center text-gray-500">
            Nessun ordine trovato
          </div>
        )}
      </div>

      <NewOrderModal
        isOpen={isNewOrderModalOpen}
        onClose={() => setIsNewOrderModalOpen(false)}
        onSubmit={handleNewOrder}
      />
    </DashboardLayout>
  )
}

