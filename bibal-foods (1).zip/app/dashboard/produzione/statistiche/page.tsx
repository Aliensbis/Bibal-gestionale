'use client'

import { useState, useEffect } from 'react'
import { Package, Scale, TrendingUp, ArrowLeft, Trash2 } from 'lucide-react'
import { DashboardLayout } from '@/components/DashboardLayout'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'
import { getAllProductions } from '@/utils/productionStorage'
import { DailyProduction } from '@/types/production'

export default function StatistichePage() {
  const [selectedPeriod, setSelectedPeriod] = useState<'giornaliero' | 'settimanale' | 'mensile'>('giornaliero')
  const [productionData, setProductionData] = useState<DailyProduction[]>([])

  // Load production data from localStorage when component mounts
  useEffect(() => {
    const loadProductionData = async () => {
      const data = await getAllProductions()
      // Sort by date in descending order (most recent first)
      data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      setProductionData(data)
    }
    loadProductionData()
  }, [])

  // Add this type guard
  const isValidProductionData = (data: any): data is DailyProduction => {
    return data && typeof data === 'object' && 'totals' in data && 
      typeof data.totals === 'object' && 'cartons' in data.totals &&
      'batches' in data.totals && 'ingredients' in data.totals;
  }

  const totalCartoni = productionData.reduce((sum, day) => sum + day.totals.cartons, 0)
  const totalPesate = productionData.reduce((sum, day) => sum + day.totals.batches, 0)

  // Calculate media giornaliera using only the last 7 days of data
  const lastWeekData = productionData.slice(0, 7)
  const mediaGiornaliera = lastWeekData.length > 0
    ? Math.round(lastWeekData.reduce((sum, day) => sum + day.totals.cartons, 0) / lastWeekData.length)
    : 0

  const resetStatistics = () => {
    if (confirm('Sei sicuro di voler azzerare tutte le statistiche?')) {
      localStorage.removeItem('productionData')
      setProductionData([])
    }
  }

  // Format date from YYYY-MM-DD to DD/MM/YYYY
  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-')
    return `${day}/${month}/${year}`
  }

  return (
    <DashboardLayout accountType="produzione">
      <div className="mb-8">
        <Link 
          href="/dashboard/produzione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Statistiche Produzione</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div 
          className="bg-white p-6 rounded-lg shadow-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Cartoni Totali</h3>
            <Package className="w-6 h-6 text-blue-500" />
          </div>
          <p className="text-3xl font-bold">{totalCartoni}</p>
        </motion.div>

        <motion.div 
          className="bg-white p-6 rounded-lg shadow-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Pesate Totali</h3>
            <Scale className="w-6 h-6 text-green-500" />
          </div>
          <p className="text-3xl font-bold">{totalPesate}</p>
        </motion.div>

        <motion.div 
          className="bg-white p-6 rounded-lg shadow-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Media Giornaliera</h3>
            <TrendingUp className="w-6 h-6 text-purple-500" />
          </div>
          <p className="text-3xl font-bold">{mediaGiornaliera}</p>
          <p className="text-sm text-gray-500 mt-1">Cartoni nell'ultima settimana</p>
        </motion.div>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div className="flex space-x-2">
          {['giornaliero', 'settimanale', 'mensile'].map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? 'default' : 'outline'}
              onClick={() => setSelectedPeriod(period as typeof selectedPeriod)}
              className="capitalize"
            >
              {period}
            </Button>
          ))}
        </div>
        
        <Button 
          variant="destructive" 
          onClick={resetStatistics}
          className="flex items-center"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Azzera Statistiche
        </Button>
      </div>

      <motion.div 
        className="bg-white rounded-lg shadow-sm"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        {productionData.filter(isValidProductionData).map((item, index) => (
          <div 
            key={item.date}
            className={`flex justify-between items-center p-4 ${
              index !== productionData.length - 1 ? 'border-b' : ''
            }`}
          >
            <div className="flex items-center">
              <span className="text-gray-900">{formatDate(item.date)}</span>
            </div>
            <div className="text-right">
              <span className="font-medium block">{item.totals.cartons} cartoni</span>
              <span className="text-sm text-gray-600 block">{item.totals.batches} pesate</span>
              <span className="text-sm text-gray-600 block">
                {item.totals.ingredients?.flourTotal 
                  ? `${item.totals.ingredients.flourTotal.toFixed(2)} kg farina`
                  : 'N/A kg farina'}
              </span>
            </div>
          </div>
        ))}
        
        {productionData.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            Nessun dato disponibile
          </div>
        )}
      </motion.div>
    </DashboardLayout>
  )
}

