'use client'

import { Factory, UserCog, Users, BarChart, Package, FileText, ShoppingCart, AlertTriangle, ClipboardCheck } from 'lucide-react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { DashboardCard } from '@/components/DashboardCard'

const cards = [
  {
    icon: Factory,
    title: 'Produzione',
    description: 'Gestisci la produzione giornaliera',
    href: '/dashboard/produzione/produzione',
    iconColor: 'text-[#492002]'
  },
  {
    icon: UserCog,
    title: 'Personale',
    description: 'Gestione del personale',
    href: '/dashboard/produzione/personale',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Users,
    title: 'Clienti',
    description: 'Gestione anagrafica clienti',
    href: '/dashboard/produzione/clienti',
    iconColor: 'text-[#492002]'
  },
  {
    icon: BarChart,
    title: 'Statistiche',
    description: 'Analisi e report dettagliati',
    href: '/dashboard/produzione/statistiche',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Package,
    title: 'Magazzino',
    description: 'Gestione del magazzino',
    href: '/dashboard/produzione/magazzino',
    iconColor: 'text-[#492002]'
  },
  {
    icon: FileText,
    title: 'Ordini',
    description: 'Gestione ordini clienti',
    href: '/dashboard/produzione/ordini',
    iconColor: 'text-[#492002]'
  },
  {
    icon: ShoppingCart,
    title: 'Acquisti',
    description: 'Gestione degli acquisti',
    href: '/dashboard/produzione/acquisti',
    iconColor: 'text-[#492002]'
  },
  {
    icon: AlertTriangle,
    title: 'Reclami',
    description: 'Gestione reclami clienti',
    href: '/dashboard/produzione/reclami',
    iconColor: 'text-[#492002]'
  },
  {
    icon: ClipboardCheck,
    title: 'HACCP',
    description: 'Controllo HACCP',
    href: '/dashboard/produzione/haccp',
    iconColor: 'text-[#492002]'
  }
]

export default function ProductionDashboard() {
  return (
    <DashboardLayout accountType="produzione" className="bg-gradient-to-br from-white to-[#492002]/10">
      <h1 className="text-3xl font-bold mb-8 text-[#492002]">Dashboard Produzione</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {cards.map((card, index) => (
          <DashboardCard key={card.title} {...card} hoverColor="hover:bg-[#492002]/5" />
        ))}
      </div>
    </DashboardLayout>
  )
}

