import { AlertTriangle } from 'lucide-react'
import { ComplaintsList } from '@/components/complaints-list'
import { DashboardLayout } from '@/components/DashboardLayout'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default function ReclamiPage() {
  return (
    <DashboardLayout accountType="produzione">
      <div className="flex items-center gap-4 mb-6">
        <Link 
          href="/dashboard/produzione" 
          className="text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-8 w-8 text-red-500" />
          <h1 className="text-2xl font-bold">Reclami Clienti</h1>
        </div>
      </div>
      
      <ComplaintsList />
    </DashboardLayout>
  )
}

