'use client'

import { useState, useEffect } from 'react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Save, Trash2, Pencil } from 'lucide-react'
import { toast } from 'react-hot-toast'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'

interface Employee {
  id: string
  name: string
}

interface DailyAssignment {
  id: string
  employeeId: string
  role: string
  date: string
  details: string
}

const roles = [
  'Operatore Macchina',
  'Addetto al Confezionamento',
  'Responsabile Qualità',
  'Magazziniere',
  'Addetto alle Pulizie',
  'Supervisore di Turno',
]

export default function PersonalePage() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [newEmployeeName, setNewEmployeeName] = useState('')
  const [dailyAssignments, setDailyAssignments] = useState<DailyAssignment[]>([])
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [selectedEmployee, setSelectedEmployee] = useState<string>('')
  const [selectedRole, setSelectedRole] = useState<string>('')
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0])
  const [assignmentDetails, setAssignmentDetails] = useState<string>('')

  useEffect(() => {
    const savedEmployees = localStorage.getItem('employees')
    if (savedEmployees) {
      setEmployees(JSON.parse(savedEmployees))
    }
    const savedAssignments = localStorage.getItem('dailyAssignments')
    if (savedAssignments) {
      setDailyAssignments(JSON.parse(savedAssignments))
    }
  }, [])

  const saveToLocalStorage = () => {
    localStorage.setItem('employees', JSON.stringify(employees))
    localStorage.setItem('dailyAssignments', JSON.stringify(dailyAssignments))
  }

  const addEmployee = () => {
    if (newEmployeeName.trim()) {
      const newEmployee = { id: Date.now().toString(), name: newEmployeeName.trim() }
      const updatedEmployees = [...employees, newEmployee]
      setEmployees(updatedEmployees)
      setNewEmployeeName('')
      saveToLocalStorage()
      toast.success('Nuovo operaio aggiunto con successo!')
    }
  }

  const removeEmployee = (id: string) => {
    const updatedEmployees = employees.filter(emp => emp.id !== id)
    setEmployees(updatedEmployees)
    setDailyAssignments(dailyAssignments.filter(assignment => assignment.employeeId !== id))
    saveToLocalStorage()
    toast.success('Operaio rimosso con successo!')
  }

  const editEmployee = (id: string, newName: string) => {
    const updatedEmployees = employees.map(emp =>
      emp.id === id ? { ...emp, name: newName } : emp
    )
    setEmployees(updatedEmployees)
    saveToLocalStorage()
    toast.success('Operaio modificato con successo!')
  }

  const addDailyAssignment = () => {
    if (selectedEmployee && selectedRole && selectedDate) {
      const newAssignment: DailyAssignment = {
        id: Date.now().toString(),
        employeeId: selectedEmployee,
        role: selectedRole,
        date: selectedDate,
        details: assignmentDetails
      }
      const updatedAssignments = [...dailyAssignments, newAssignment]
      setDailyAssignments(updatedAssignments)
      saveToLocalStorage()
      toast.success('Assegnazione giornaliera salvata con successo!')
      // Reset form
      setSelectedEmployee('')
      setSelectedRole('')
      setAssignmentDetails('')
    } else {
      toast.error('Per favore, compila tutti i campi obbligatori.')
    }
  }

  return (
    <DashboardLayout accountType="produzione">
      <h1 className="text-2xl font-bold mb-6">Gestione Personale</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Aggiungi Nuovo Operaio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Nome del nuovo operaio"
              value={newEmployeeName}
              onChange={(e) => setNewEmployeeName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addEmployee()}
            />
            <Button onClick={addEmployee}>
              <Plus className="mr-2 h-4 w-4" /> Aggiungi
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Lista Operai</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome Operaio</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>{employee.name}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => setEditingEmployee(employee)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => removeEmployee(employee.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Assegnazione Giornaliera</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Operaio</label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona operaio" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Mansione</label>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona mansione" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Data</label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Dettagli</label>
              <Textarea
                placeholder="Inserisci dettagli sulla giornata lavorativa..."
                value={assignmentDetails}
                onChange={(e) => setAssignmentDetails(e.target.value)}
              />
            </div>
            <Button onClick={addDailyAssignment}>
              <Save className="mr-2 h-4 w-4" /> Salva Assegnazione
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Storico Mansioni</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Operaio</TableHead>
                <TableHead>Mansione</TableHead>
                <TableHead>Dettagli</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dailyAssignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell>{assignment.date}</TableCell>
                  <TableCell>{employees.find(emp => emp.id === assignment.employeeId)?.name}</TableCell>
                  <TableCell>{assignment.role}</TableCell>
                  <TableCell>{assignment.details}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {editingEmployee && (
        <Dialog open={!!editingEmployee} onOpenChange={() => setEditingEmployee(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Modifica Operaio</DialogTitle>
            </DialogHeader>
            <Input
              value={editingEmployee.name}
              onChange={(e) => setEditingEmployee({ ...editingEmployee, name: e.target.value })}
            />
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingEmployee(null)}>Annulla</Button>
              <Button onClick={() => {
                editEmployee(editingEmployee.id, editingEmployee.name)
                setEditingEmployee(null)
              }}>Salva</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </DashboardLayout>
  )
}

