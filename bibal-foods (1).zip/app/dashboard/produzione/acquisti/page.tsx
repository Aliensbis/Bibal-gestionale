import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function AcquistiPage() {
  return <PlaceholderPage accountType="produzione" title="Gestione Acquisti" />
}

