'use client'

import { useState, useEffect } from 'react'
import { Package, History, Plus, Pencil, Trash2 } from 'lucide-react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Product, InventoryMovement } from '@/types/inventory'
import { products } from '@/utils/productionData'

export default function MagazzinoPage() {
  const [movements, setMovements] = useState<InventoryMovement[]>([])
  const [selectedProduct, setSelectedProduct] = useState<string>('')
  const [movementType, setMovementType] = useState<'in' | 'out'>('in')
  const [quantity, setQuantity] = useState('')
  const [note, setNote] = useState('')
  const [showHistory, setShowHistory] = useState(false)

  // Load movements from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('inventory_movements')
    if (stored) {
      setMovements(JSON.parse(stored))
    }
  }, [])

  // Save movements to localStorage when they change
  useEffect(() => {
    localStorage.setItem('inventory_movements', JSON.stringify(movements))
  }, [movements])

  const getCurrentStock = (productId: string): number => {
    return movements.reduce((stock, movement) => {
      if (movement.productId === productId) {
        return stock + (movement.type === 'in' ? movement.quantity : -movement.quantity)
      }
      return stock
    }, 0)
  }

  const handleMovement = () => {
    if (!selectedProduct || !quantity) return

    const quantityNum = parseInt(quantity)
    if (isNaN(quantityNum) || quantityNum <= 0) {
      alert('Inserisci una quantità valida')
      return
    }

    if (movementType === 'out') {
      const currentStock = getCurrentStock(selectedProduct)
      if (quantityNum > currentStock) {
        alert('Quantità non disponibile in magazzino!')
        return
      }
    }

    const newMovement: InventoryMovement = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      productId: selectedProduct,
      type: movementType,
      quantity: quantityNum,
      note: note || undefined
    }

    setMovements(prev => [...prev, newMovement])
    setSelectedProduct('')
    setQuantity('')
    setNote('')
  }

  const getStockStatus = (quantity: number) => {
    if (quantity === 0) return 'text-red-600'
    if (quantity < 10) return 'text-yellow-600'
    return 'text-green-600'
  }

  return (
    <DashboardLayout accountType="produzione">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <Package className="h-8 w-8 text-purple-600 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900">Gestione Magazzino</h1>
        </div>
        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center"
          >
            <History className="w-4 h-4 mr-2" />
            {showHistory ? 'Nascondi Storico' : 'Mostra Storico'}
          </Button>
          <Button className="flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            Nuovo Prodotto
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column - New Movement Form */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-semibold mb-6">Nuovo Movimento</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Prodotto</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona prodotto" />
                </SelectTrigger>
                <SelectContent>
                  {products.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button
                variant={movementType === 'in' ? 'default' : 'outline'}
                onClick={() => setMovementType('in')}
                className="w-full"
              >
                Entrata
              </Button>
              <Button
                variant={movementType === 'out' ? 'default' : 'outline'}
                onClick={() => setMovementType('out')}
                className="w-full"
              >
                Uscita
              </Button>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">
                Quantità (cartoni)
              </label>
              <Input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">
                Note (opzionale)
              </label>
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Aggiungi una nota..."
              />
            </div>

            <Button
              onClick={handleMovement}
              className="w-full"
              disabled={!selectedProduct || !quantity}
            >
              Registra Movimento
            </Button>
          </div>
        </div>

        {/* Right Column - Current Stock */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-semibold mb-6">Prodotti</h2>
          <div className="space-y-4">
            {products.map(product => {
              const stock = getCurrentStock(product.id)
              return (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <h3 className="font-medium">{product.name}</h3>
                    <p className="text-sm text-gray-500">
                      {product.cartonsPerBatch} cartoni per pesata
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`font-medium ${getStockStatus(stock)}`}>
                      {stock} cartoni
                    </span>
                    <Button variant="ghost" size="icon">
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div></div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Movement History */}
      {showHistory && (
        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-semibold mb-6">Storico Movimenti</h2>
          <div className="space-y-4">
            {movements.map(movement => {
              const product = products.find(p => p.id === movement.productId)
              return (
                <div
                  key={movement.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{product?.name}</span>
                      <span className={`text-sm ${
                        movement.type === 'in' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {movement.type === 'in' ? 'Entrata' : 'Uscita'}
                      </span>
                    </div>
                    {movement.note && (
                      <p className="text-sm text-gray-500">{movement.note}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-medium">
                      {movement.quantity} cartoni
                    </span>
                    <span className="text-sm text-gray-500">
                      {new Date(movement.date).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              )
            })}
            {movements.length === 0 && (
              <p className="text-center text-gray-500">
                Nessun movimento registrato
              </p>
            )}
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}

