'use client'

import { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Save, Trash2, Pencil } from 'lucide-react'
import { toast } from 'react-hot-toast'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'

interface Client {
  id: string
  name: string
  email: string
  phone: string
  address: string
}

export default function ClientiPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [newClient, setNewClient] = useState<Omit<Client, 'id'>>({ name: '', email: '', phone: '', address: '' })
  const [editingClient, setEditingClient] = useState<Client | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const pathname = usePathname()
  const accountType = pathname.includes('/produzione') ? 'produzione' : 'amministrazione'

  useEffect(() => {
    const savedClients = localStorage.getItem('clients')
    if (savedClients) {
      setClients(JSON.parse(savedClients))
    }
  }, [])

  const saveToLocalStorage = (updatedClients: Client[]) => {
    localStorage.setItem('clients', JSON.stringify(updatedClients))
  }

  const handleAddClient = () => {
    if (newClient.name && newClient.email) {
      const clientToAdd = { ...newClient, id: Date.now().toString() }
      const updatedClients = [...clients, clientToAdd]
      setClients(updatedClients)
      saveToLocalStorage(updatedClients)
      setNewClient({ name: '', email: '', phone: '', address: '' })
      setIsDialogOpen(false)
      toast.success('Nuovo cliente aggiunto con successo!')
    } else {
      toast.error('Nome e email sono campi obbligatori.')
    }
  }

  const handleEditClient = () => {
    if (editingClient) {
      const updatedClients = clients.map(client =>
        client.id === editingClient.id ? editingClient : client
      )
      setClients(updatedClients)
      saveToLocalStorage(updatedClients)
      setEditingClient(null)
      toast.success('Cliente modificato con successo!')
    }
  }

  const handleDeleteClient = (id: string) => {
    const updatedClients = clients.filter(client => client.id !== id)
    setClients(updatedClients)
    saveToLocalStorage(updatedClients)
    toast.success('Cliente eliminato con successo!')
  }

  return (
    <DashboardLayout accountType={accountType}>
      <h1 className="text-2xl font-bold mb-6">Gestione Clienti</h1>

      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Lista Clienti</CardTitle>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> Aggiungi Cliente
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Telefono</TableHead>
                <TableHead>Indirizzo</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clients.map((client) => (
                <TableRow key={client.id}>
                  <TableCell>{client.name}</TableCell>
                  <TableCell>{client.email}</TableCell>
                  <TableCell>{client.phone}</TableCell>
                  <TableCell>{client.address}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => setEditingClient(client)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDeleteClient(client.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aggiungi Nuovo Cliente</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="name" className="text-right">
                Nome
              </label>
              <Input
                id="name"
                value={newClient.name}
                onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="email" className="text-right">
                Email
              </label>
              <Input
                id="email"
                value={newClient.email}
                onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="phone" className="text-right">
                Telefono
              </label>
              <Input
                id="phone"
                value={newClient.phone}
                onChange={(e) => setNewClient({ ...newClient, phone: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="address" className="text-right">
                Indirizzo
              </label>
              <Input
                id="address"
                value={newClient.address}
                onChange={(e) => setNewClient({ ...newClient, address: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleAddClient}>Aggiungi Cliente</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingClient} onOpenChange={() => setEditingClient(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifica Cliente</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="edit-name" className="text-right">
                Nome
              </label>
              <Input
                id="edit-name"
                value={editingClient?.name || ''}
                onChange={(e) => setEditingClient(editingClient ? { ...editingClient, name: e.target.value } : null)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="edit-email" className="text-right">
                Email
              </label>
              <Input
                id="edit-email"
                value={editingClient?.email || ''}
                onChange={(e) => setEditingClient(editingClient ? { ...editingClient, email: e.target.value } : null)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="edit-phone" className="text-right">
                Telefono
              </label>
              <Input
                id="edit-phone"
                value={editingClient?.phone || ''}
                onChange={(e) => setEditingClient(editingClient ? { ...editingClient, phone: e.target.value } : null)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="edit-address" className="text-right">
                Indirizzo
              </label>
              <Input
                id="edit-address"
                value={editingClient?.address || ''}
                onChange={(e) => setEditingClient(editingClient ? { ...editingClient, address: e.target.value } : null)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleEditClient}>Salva Modifiche</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}

