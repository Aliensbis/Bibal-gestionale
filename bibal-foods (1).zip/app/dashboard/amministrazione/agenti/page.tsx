import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function AgentiPage() {
  return <PlaceholderPage accountType="amministrazione" title="Gestione Agenti" />
}

