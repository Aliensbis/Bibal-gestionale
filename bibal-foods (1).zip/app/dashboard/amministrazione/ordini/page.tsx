'use client'

import { useState, useEffect } from 'react'
import { ShoppingBag, Plus, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Button } from '@/components/ui/button'
import { OrderStats } from '@/components/OrderStats'
import { OrderFilters } from '@/components/OrderFilters'
import { OrderList } from '@/components/OrderList'
import { NewOrderModal } from '@/components/NewOrderModal'
import { Order, OrderStatus } from '@/types/orders'
import { subscribeToOrders, createOrder, updateOrderStatus } from '@/utils/orderUtils'
import { toast } from 'react-hot-toast'

export default function OrdiniPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false)

  useEffect(() => {
    const unsubscribe = subscribeToOrders((updatedOrders) => {
      setOrders(updatedOrders)
      setFilteredOrders(updatedOrders)
    })

    return () => unsubscribe()
  }, [])

  const handleCreateOrder = async (orderData: Omit<Order, 'id'>) => {
    try {
      await createOrder(orderData)
      toast.success('Ordine creato con successo')
      setIsNewOrderModalOpen(false)
    } catch (error) {
      toast.error('Errore durante la creazione dell\'ordine')
    }
  }

  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus)
      toast.success(`Stato dell'ordine aggiornato a ${newStatus}`)
    } catch (error) {
      toast.error('Errore durante l\'aggiornamento dello stato dell\'ordine')
    }
  }

  const handleFilterOrders = (filteredOrders: Order[]) => {
    setFilteredOrders(filteredOrders)
  }

  return (
    <DashboardLayout accountType="amministrazione">
      <div className="mb-8">
        <Link 
          href="/dashboard/amministrazione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <ShoppingBag className="h-8 w-8 text-indigo-600 mr-2" />
          <h1 className="text-2xl font-bold">Gestione Ordini</h1>
        </div>
        <Button onClick={() => setIsNewOrderModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nuovo Ordine
        </Button>
      </div>

      <OrderStats orders={orders} />

      <OrderFilters orders={orders} onFilterChange={handleFilterOrders} />

      <OrderList 
        orders={filteredOrders} 
        onUpdateStatus={handleUpdateOrderStatus}
      />

      <NewOrderModal
        isOpen={isNewOrderModalOpen}
        onClose={() => setIsNewOrderModalOpen(false)}
        onSubmit={handleCreateOrder}
      />
    </DashboardLayout>
  )
}

