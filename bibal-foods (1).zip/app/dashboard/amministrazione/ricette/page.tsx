'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Search, Plus, Pencil } from 'lucide-react'
import Link from 'next/link'
import { DashboardLayout } from '@/components/DashboardLayout'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { EditRecipeDialog } from '@/components/EditRecipeDialog'
import { Product } from '@/types/production'
import { getAllRecipes, updateRecipe, addRecipe } from '@/utils/recipeStorage'
import { toast } from 'react-hot-toast'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export default function RicettePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [recipes, setRecipes] = useState<Product[]>([])
  const [editingRecipe, setEditingRecipe] = useState<Product | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAddingNewRecipe, setIsAddingNewRecipe] = useState(false)

  useEffect(() => {
    loadRecipes()
  }, [])

  const loadRecipes = async () => {
    try {
      setIsLoading(true)
      const data = await getAllRecipes()
      setRecipes(data)
    } catch (error) {
      toast.error('Errore nel caricamento delle ricette')
    } finally {
      setIsLoading(false)
    }
  }

  const handleEditRecipe = async (recipeId: string, updates: Partial<Product>) => {
    try {
      const updatedRecipes = await updateRecipe(recipeId, updates)
      setRecipes(updatedRecipes)
      toast.success('Ricetta aggiornata con successo')
    } catch (error) {
      toast.error('Errore durante l\'aggiornamento della ricetta')
    }
  }

  const handleAddNewRecipe = async (newRecipe: Omit<Product, 'id'>) => {
    try {
      const updatedRecipes = await addRecipe(newRecipe)
      setRecipes(updatedRecipes)
      toast.success('Nuova ricetta aggiunta con successo')
    } catch (error) {
      toast.error('Errore durante l\'aggiunta della nuova ricetta')
    }
  }

  const filteredRecipes = recipes.filter(recipe => 
    recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (categoryFilter === 'all' || recipe.category === categoryFilter)
  )

  if (isLoading) {
    return (
      <DashboardLayout accountType="amministrazione">
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout accountType="amministrazione">
      <div className="mb-8">
        <Link 
          href="/dashboard/amministrazione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Ricette</h1>
        <Button 
          className="bg-purple-600 hover:bg-purple-700"
          onClick={() => setIsAddingNewRecipe(true)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Nuova Ricetta
        </Button>
      </div>

      <div className="mb-6 flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Cerca ricetta..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full md:w-[200px]">
            <SelectValue placeholder="Filtra per categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le categorie</SelectItem>
            <SelectItem value="Babà">Babà</SelectItem>
            <SelectItem value="Savarè">Savarè</SelectItem>
            <SelectItem value="Bignè">Bignè</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecipes.map((recipe) => (
          <Card key={recipe.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xl font-semibold">{recipe.name}</CardTitle>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setEditingRecipe(recipe)}
                className="hover:bg-purple-50"
              >
                <Pencil className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-2">Categoria: {recipe.category}</p>
              <p className="text-sm mb-2">Cartoni per pesata: {recipe.cartonsPerBatch}</p>
              <h3 className="font-medium mb-1">Ingredienti:</h3>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li>Farina {recipe.ingredients.flour.type}: {recipe.ingredients.flour.amount} kg</li>
                <li>Uova: {recipe.ingredients.eggs} kg</li>
                <li>Zucchero: {recipe.ingredients.sugar} kg</li>
                <li>Sale: {recipe.ingredients.salt} kg</li>
                <li>Lievito: {recipe.ingredients.yeast} kg</li>
                <li>Margarina: {recipe.ingredients.margarine} kg</li>
                {recipe.ingredients.e202 > 0 && <li>E202: {recipe.ingredients.e202} kg</li>}
                {recipe.ingredients.oil > 0 && <li>Olio: {recipe.ingredients.oil} kg</li>}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <EditRecipeDialog
        recipe={editingRecipe}
        isOpen={!!editingRecipe || isAddingNewRecipe}
        onClose={() => {
          setEditingRecipe(null)
          setIsAddingNewRecipe(false)
        }}
        onSave={editingRecipe ? handleEditRecipe : handleAddNewRecipe}
        isNewRecipe={isAddingNewRecipe}
      />
    </DashboardLayout>
  )
}

