'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Package } from 'lucide-react'
import Link from 'next/link'
import { DashboardLayout } from '@/components/DashboardLayout'
import { ClientList } from '@/components/statistics/ClientList'
import { StatsDisplay } from '@/components/statistics/StatsDisplay'
import { OrderHistory } from '@/components/statistics/OrderHistory'
import { Button } from '@/components/ui/button'
import { ClientStats, OrderHistoryItem } from '@/types/statistics'
import { loadData, updateClient, updateOrder } from '@/utils/statisticsData'

export default function StatistichePage() {
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null)
  const [period, setPeriod] = useState<'weekly' | 'monthly' | 'yearly'>('monthly')
  const [clients, setClients] = useState<ClientStats[]>([])
  const [orders, setOrders] = useState<OrderHistoryItem[]>([])

  useEffect(() => {
    const data = loadData()
    setClients(data.clients)
    setOrders(data.orders)
    if (data.clients.length > 0) {
      setSelectedClientId(data.clients[0].id)
    }
  }, [])

  const handleUpdateClient = (clientId: string, updates: Partial<ClientStats>) => {
    const updatedClients = updateClient(clientId, updates)
    setClients(updatedClients)
  }

  const handleUpdateOrder = (orderId: string, updates: Partial<OrderHistoryItem>) => {
    const updatedOrders = updateOrder(orderId, updates)
    setOrders(updatedOrders)
  }

  const selectedClient = clients.find(c => c.id === selectedClientId)

  return (
    <DashboardLayout accountType="amministrazione">
      <div className="mb-8">
        <Link 
          href="/dashboard/amministrazione"
          className="inline-flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Indietro
        </Link>
      </div>

      <h1 className="text-2xl font-bold mb-8">Statistiche Clienti</h1>
      
      <div className="flex space-x-4 mb-8">
        <Button
          variant={period === 'weekly' ? 'default' : 'outline'}
          onClick={() => setPeriod('weekly')}
        >
          Settimana
        </Button>
        <Button
          variant={period === 'monthly' ? 'default' : 'outline'}
          onClick={() => setPeriod('monthly')}
        >
          Mese
        </Button>
        <Button
          variant={period === 'yearly' ? 'default' : 'outline'}
          onClick={() => setPeriod('yearly')}
        >
          Anno
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <ClientList
            clients={clients}
            selectedClientId={selectedClientId}
            onSelectClient={setSelectedClientId}
            onUpdateClient={handleUpdateClient}
          />
        </div>

        <div className="lg:col-span-3 space-y-8">
          {selectedClient && (
            <>
              <StatsDisplay
                client={selectedClient}
                period={period}
              />
              <OrderHistory
                orders={orders}
                onUpdateOrder={handleUpdateOrder}
              />
            </>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}

