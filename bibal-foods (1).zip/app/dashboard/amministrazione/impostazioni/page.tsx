import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function ImpostazioniPage() {
  return <PlaceholderPage accountType="amministrazione" title="Impostazioni" />
}

