import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function ClientiPage() {
  return <PlaceholderPage accountType="amministrazione" title="Gestione Clienti" />
}

