import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function FatturazionePage() {
  return <PlaceholderPage accountType="amministrazione" title="Gestione Fatturazione" />
}

