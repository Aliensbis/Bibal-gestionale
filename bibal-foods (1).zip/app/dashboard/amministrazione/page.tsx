'use client'

import { BarChart, FileText, CreditCard, Users, UserCheck, AlertTriangle, Settings, Book } from 'lucide-react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { DashboardCard } from '@/components/DashboardCard'

const cards = [
  {
    icon: BarChart,
    title: 'Statistiche',
    description: 'Analisi e report dettagliati',
    href: '/dashboard/amministrazione/statistiche',
    iconColor: 'text-[#492002]'
  },
  {
    icon: FileText,
    title: 'Ordini',
    description: 'Gestione ordini clienti',
    href: '/dashboard/amministrazione/ordini',
    iconColor: 'text-[#492002]'
  },
  {
    icon: CreditCard,
    title: 'Fatturazione',
    description: 'Gestione fatture e pagamenti',
    href: '/dashboard/amministrazione/fatturazione',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Users,
    title: 'Clienti',
    description: 'Gestione anagrafica clienti',
    href: '/dashboard/amministrazione/clienti',
    iconColor: 'text-[#492002]'
  },
  {
    icon: UserCheck,
    title: 'Agenti',
    description: 'Gestione agenti commerciali',
    href: '/dashboard/amministrazione/agenti',
    iconColor: 'text-[#492002]'
  },
  {
    icon: AlertTriangle,
    title: 'Reclami',
    description: 'Gestione reclami clienti',
    href: '/dashboard/amministrazione/reclami',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Book,
    title: 'Ricette',
    description: 'Gestione ricette prodotti',
    href: '/dashboard/amministrazione/ricette',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Settings,
    title: 'Impostazioni',
    description: 'Configurazione del sistema',
    href: '/dashboard/amministrazione/impostazioni',
    iconColor: 'text-[#492002]'
  }
]

export default function AmministrazioneDashboard() {
  return (
    <DashboardLayout accountType="amministrazione" className="bg-gradient-to-br from-white to-[#492002]/10">
      <h1 className="text-3xl font-bold mb-8 text-[#492002]">Dashboard Amministrazione</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {cards.map((card, index) => (
          <DashboardCard key={card.title} {...card} hoverColor="hover:bg-[#492002]/5" />
        ))}
      </div>
    </DashboardLayout>
  )
}

