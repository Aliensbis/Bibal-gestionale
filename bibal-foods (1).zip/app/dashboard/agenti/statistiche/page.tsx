import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function StatistichePage() {
  return <PlaceholderPage accountType="agenti" title="Statistiche" />
}

