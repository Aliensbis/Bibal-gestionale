import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function OrdiniPage() {
  return <PlaceholderPage accountType="agenti" title="Gestione Ordini" />
}

