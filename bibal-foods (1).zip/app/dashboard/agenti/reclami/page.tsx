import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function ReclamiPage() {
  return <PlaceholderPage accountType="agenti" title="Gestione Reclami" />
}

