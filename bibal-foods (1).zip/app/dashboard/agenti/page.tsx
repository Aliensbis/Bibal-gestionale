'use client'

import { motion } from 'framer-motion'
import { Users, FileText, BarChart, AlertTriangle, Settings } from 'lucide-react'
import { DashboardCard } from '@/components/DashboardCard'

const cards = [
  {
    icon: Users,
    title: 'Clienti',
    description: 'Gestione anagrafica clienti',
    href: '/dashboard/agenti/clienti',
    iconColor: 'text-[#492002]'
  },
  {
    icon: FileText,
    title: 'Ordini',
    description: 'Gestione ordini clienti',
    href: '/dashboard/agenti/ordini',
    iconColor: 'text-[#492002]'
  },
  {
    icon: BarChart,
    title: 'Statistiche',
    description: 'Analisi e report dettagliati',
    href: '/dashboard/agenti/statistiche',
    iconColor: 'text-[#492002]'
  },
  {
    icon: AlertTriangle,
    title: 'Reclami',
    description: 'Gestione reclami clienti',
    href: '/dashboard/agenti/reclami',
    iconColor: 'text-[#492002]'
  },
  {
    icon: Settings,
    title: 'Impostazioni',
    description: 'Configurazione del profilo',
    href: '/dashboard/agenti/impostazioni',
    iconColor: 'text-[#492002]'
  }
]

export default function AgentiDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-[#492002]/10">
      {/*Removed TopNav component*/}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-[#492002]">Dashboard Agenti</h1>
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {cards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ 
                scale: 1.05, 
                backgroundColor: 'rgba(73, 32, 2, 0.05)',
                transition: { duration: 0.2 } 
              }}
            >
              <DashboardCard key={card.title} {...card} hoverColor="hover:bg-[#492002]/5" />
            </motion.div>
          ))}
        </motion.div>
      </main>
    </div>
  )
}

