import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function ImpostazioniPage() {
  return <PlaceholderPage accountType="agenti" title="Impostazioni" />
}

