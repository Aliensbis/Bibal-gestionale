import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function ClientiPage() {
  return <PlaceholderPage accountType="agenti" title="Gestione Clienti" />
}

